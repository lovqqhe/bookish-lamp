#!/usr/bin/env python3
# -*- coding: utf-8 -*-

import os
import sys

# 添加当前目录到Python路径
current_dir = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, current_dir)

def setup_database():
    """设置数据库"""
    try:
        # 导入必要的模块
        from flask import Flask
        from models import db, User
        from flask_bcrypt import Bcrypt
        
        # 创建Flask应用
        app = Flask(__name__)
        app.config['SECRET_KEY'] = 'your-secret-key-here'
        app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///recipes.db'
        app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
        
        # 初始化扩展
        db.init_app(app)
        bcrypt = Bcrypt(app)
        
        with app.app_context():
            print("正在创建数据库表...")
            
            # 创建所有表
            db.create_all()
            print("✓ 数据库表创建成功！")
            
            # 检查是否已有用户
            if User.query.first() is None:
                print("正在创建示例用户...")
                hashed_password = bcrypt.generate_password_hash('password123').decode('utf-8')
                demo_user = User(username='demo', email='demo@example.com', password_hash=hashed_password)
                db.session.add(demo_user)
                db.session.commit()
                print("✓ 示例用户创建成功: demo / password123")
            else:
                print("✓ 数据库中已有用户数据")
            
            print("\n数据库初始化完成！")
            print("现在可以启动应用了。")
            
    except Exception as e:
        print(f"❌ 数据库初始化失败: {e}")
        import traceback
        traceback.print_exc()
        return False
    
    return True

if __name__ == '__main__':
    print("=== 智能食谱生成器 - 数据库初始化 ===")
    success = setup_database()
    if success:
        print("\n✅ 数据库初始化成功！")
    else:
        print("\n❌ 数据库初始化失败！")
        sys.exit(1)
