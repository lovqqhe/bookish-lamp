import os
import requests
import json
import uuid
import random
from datetime import datetime, timedelta
from flask import Flask, request, jsonify
from flask_cors import CORS
from dotenv import load_dotenv

# 加载 .env 文件中的环境变量
load_dotenv()

app = Flask(__name__)
# 允许来自前端开发服务器(http://localhost:5173)的跨域请求
CORS(app, resources={r"/api/*": {"origins": "http://localhost:5173"}})

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"
WEATHER_API_KEY = os.getenv("WEATHER_API_KEY", "demo")  # 使用免费天气API

# 简单的内存存储（生产环境应使用数据库）
travel_history = []
budget_templates = {
    "经济": {"住宿": 0.3, "餐饮": 0.25, "交通": 0.2, "门票": 0.15, "其他": 0.1},
    "中等": {"住宿": 0.35, "餐饮": 0.3, "交通": 0.2, "门票": 0.1, "其他": 0.05},
    "豪华": {"住宿": 0.4, "餐饮": 0.35, "交通": 0.15, "门票": 0.05, "其他": 0.05},
    "不限": {"住宿": 0.3, "餐饮": 0.3, "交通": 0.2, "门票": 0.1, "其他": 0.1}
}

# 目的地数据库
destinations_database = {
    "文化历史": [
        {"name": "意大利罗马", "country": "意大利", "reason": "古罗马文化遗址丰富，斗兽场、梵蒂冈等世界文化遗产", "budget_level": "中等", "best_time": "春秋季", "highlights": ["斗兽场", "梵蒂冈博物馆", "许愿池", "万神殿"]},
        {"name": "希腊雅典", "country": "希腊", "reason": "古希腊文明发源地，卫城、帕特农神庙等古迹", "budget_level": "经济", "best_time": "春秋季", "highlights": ["卫城", "帕特农神庙", "宙斯神庙", "古罗马市集"]},
        {"name": "埃及开罗", "country": "埃及", "reason": "古埃及文明遗迹，金字塔、狮身人面像", "budget_level": "经济", "best_time": "冬季", "highlights": ["吉萨金字塔", "狮身人面像", "埃及博物馆", "尼罗河"]},
        {"name": "中国西安", "country": "中国", "reason": "古都文化，兵马俑、古城墙", "budget_level": "经济", "best_time": "春秋季", "highlights": ["兵马俑", "古城墙", "大雁塔", "华清池"]},
        {"name": "日本京都", "country": "日本", "reason": "传统文化与现代融合，寺庙、神社", "budget_level": "中等", "best_time": "春秋季", "highlights": ["金阁寺", "清水寺", "伏见稻荷大社", "岚山竹林"]}
    ],
    "美食料理": [
        {"name": "日本东京", "country": "日本", "reason": "世界顶级美食之都，寿司、拉面、天妇罗", "budget_level": "中等", "best_time": "春秋季", "highlights": ["筑地市场", "银座", "浅草寺", "东京塔"]},
        {"name": "法国巴黎", "country": "法国", "reason": "法式美食天堂，米其林餐厅、法式甜点", "budget_level": "豪华", "best_time": "春秋季", "highlights": ["埃菲尔铁塔", "卢浮宫", "凯旋门", "塞纳河"]},
        {"name": "泰国曼谷", "country": "泰国", "reason": "街头美食丰富，泰式料理、夜市", "budget_level": "经济", "best_time": "冬季", "highlights": ["大皇宫", "卧佛寺", "考山路", "水上市场"]},
        {"name": "意大利米兰", "country": "意大利", "reason": "意式美食，披萨、意面、咖啡文化", "budget_level": "中等", "best_time": "春秋季", "highlights": ["米兰大教堂", "斯卡拉歌剧院", "斯福尔扎城堡", "纳维利运河"]},
        {"name": "韩国首尔", "country": "韩国", "reason": "韩式料理，泡菜、烤肉、韩式炸鸡", "budget_level": "中等", "best_time": "春秋季", "highlights": ["景福宫", "明洞", "弘大", "南山塔"]}
    ],
    "自然风光": [
        {"name": "新西兰", "country": "新西兰", "reason": "自然风光壮丽，雪山、湖泊、草原", "budget_level": "中等", "best_time": "春秋季", "highlights": ["米尔福德峡湾", "皇后镇", "罗托鲁瓦", "霍比特人村"]},
        {"name": "瑞士", "country": "瑞士", "reason": "阿尔卑斯山美景，雪山、湖泊、小镇", "budget_level": "豪华", "best_time": "夏季", "highlights": ["少女峰", "卢塞恩湖", "因特拉肯", "苏黎世"]},
        {"name": "尼泊尔", "country": "尼泊尔", "reason": "喜马拉雅山脉，徒步、登山", "budget_level": "经济", "best_time": "春秋季", "highlights": ["珠穆朗玛峰", "加德满都", "博卡拉", "奇特旺国家公园"]},
        {"name": "加拿大班夫", "country": "加拿大", "reason": "落基山脉，国家公园、湖泊", "budget_level": "中等", "best_time": "夏季", "highlights": ["班夫国家公园", "露易丝湖", "梦莲湖", "哥伦比亚冰原"]},
        {"name": "澳大利亚大堡礁", "country": "澳大利亚", "reason": "珊瑚礁、海洋生物、潜水", "budget_level": "中等", "best_time": "冬季", "highlights": ["大堡礁", "凯恩斯", "圣灵群岛", "道格拉斯港"]}
    ],
    "购物时尚": [
        {"name": "美国纽约", "country": "美国", "reason": "时尚购物天堂，第五大道、时代广场", "budget_level": "豪华", "best_time": "春秋季", "highlights": ["自由女神像", "中央公园", "百老汇", "布鲁克林大桥"]},
        {"name": "韩国首尔", "country": "韩国", "reason": "韩流时尚中心，明洞、弘大", "budget_level": "中等", "best_time": "春秋季", "highlights": ["明洞", "弘大", "东大门", "江南区"]},
        {"name": "迪拜", "country": "阿联酋", "reason": "奢侈品购物胜地，购物中心、黄金市场", "budget_level": "豪华", "best_time": "冬季", "highlights": ["哈利法塔", "帆船酒店", "棕榈岛", "迪拜购物中心"]},
        {"name": "法国巴黎", "country": "法国", "reason": "时尚之都，香榭丽舍大街、老佛爷", "budget_level": "豪华", "best_time": "春秋季", "highlights": ["香榭丽舍大街", "老佛爷百货", "蒙田大道", "玛莱区"]},
        {"name": "日本大阪", "country": "日本", "reason": "购物天堂，心斋桥、道顿堀", "budget_level": "中等", "best_time": "春秋季", "highlights": ["心斋桥", "道顿堀", "大阪城", "环球影城"]}
    ],
    "海滩度假": [
        {"name": "马尔代夫", "country": "马尔代夫", "reason": "天堂般的海滩，水上屋、潜水", "budget_level": "豪华", "best_time": "冬季", "highlights": ["马累", "水上屋", "潜水", "日落巡航"]},
        {"name": "巴厘岛", "country": "印度尼西亚", "reason": "热带海滩，文化体验、冲浪", "budget_level": "中等", "best_time": "冬季", "highlights": ["库塔海滩", "乌布", "海神庙", "金巴兰海滩"]},
        {"name": "夏威夷", "country": "美国", "reason": "火山海滩，冲浪、草裙舞", "budget_level": "豪华", "best_time": "春秋季", "highlights": ["威基基海滩", "珍珠港", "火山国家公园", "檀香山"]},
        {"name": "普吉岛", "country": "泰国", "reason": "安达曼海海滩，潜水、夜生活", "budget_level": "中等", "best_time": "冬季", "highlights": ["芭东海滩", "皮皮岛", "大佛", "幻多奇乐园"]},
        {"name": "圣托里尼", "country": "希腊", "reason": "爱琴海美景，蓝顶教堂、日落", "budget_level": "中等", "best_time": "夏季", "highlights": ["伊亚", "费拉", "火山岛", "红沙滩"]}
    ]
}

@app.route('/api/generate-plan', methods=['POST'])
def generate_plan():
    if not DEEPSEEK_API_KEY:
        return jsonify(
            {"error": "DeepSeek API key not found. Please set the DEEPSEEK_API_KEY environment variable."}), 500

    data = request.json
    destination = data.get('destination')
    duration = data.get('duration')
    interests = data.get('interests', '无特殊偏好')
    budget = data.get('budget', '不限')

    if not destination or not duration:
        return jsonify({"error": "Destination and duration are required."}), 400

    # --- AI Prompt Engineering ---
    prompt = f"""
    你是一位经验丰富的世界级旅行规划师。请根据以下用户需求，为他们量身打造一份详尽、实用且激动人心的旅行计划。

    **用户需求:**
    - **目的地:** {destination}
    - **旅行天数:** {duration} 天
    - **兴趣与偏好:** {interests}
    - **预算水平:** {budget}

    **输出要求:**
    请务**严格**按照下面的Markdown格式生成旅行计划。不要添加任何额外的开场白或总结。

    # {destination} {duration}日深度游行程规划

    ## 总体概览与建议
    在这里简要介绍本次旅行的亮点、风格以及一些关键建议（如最佳旅行季节、必备物品等）。

    ## 每日行程安排

    ### 第一天: [当天主题，例如：抵达与城市初探]
    *   **上午:** [时间段] - [活动名称]。[活动简介]。
    *   **午餐:** [推荐餐厅类型或名称]。[简要理由]。
    *   **下午:** [时间段] - [活动名称]。[活动简介]。
    *   **晚餐:** [推荐餐厅类型或名称]。[简要理由]。
    *   **住宿:** [推荐区域或酒店类型]。

    ### 第二天: [当天主题]
    *   **上午:** [时间段] - [活动名称]。[活动简介]。
    *   **午餐:** [推荐餐厅类型或名称]。[简要理由]。
    *   **下午:** [时间段] - [活动名称]。[活动简介]。
    *   **晚餐:** [推荐餐厅类型或名称]。[简要理由]。
    *   **住宿:** [推荐区域或酒店类型]。

    (请按照旅行天数，为每一天生成类似的详细安排)

    ## 预算估算
    - **交通:** [估算费用]
    - **住宿:** [估算费用]
    - **餐饮:** [估算费用]
    - **门票与活动:** [估算费用]
    - **总计:** [估算总费用]

    ## 旅行小贴士
    - [贴士1]
    - [贴士2]
    """

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
    }

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "你是一位经验丰富的世界级旅行规划师。"},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.75,
        "max_tokens": 3000,
        "stream": False
    }

    try:
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=payload, timeout=180)
        response.raise_for_status()

        result = response.json()
        plan_content = result['choices'][0]['message']['content']

        # 保存到历史记录
        plan_id = str(uuid.uuid4())
        plan_record = {
            "id": plan_id,
            "destination": destination,
            "duration": duration,
            "interests": interests,
            "budget": budget,
            "plan": plan_content,
            "created_at": datetime.now().isoformat(),
            "total_budget": calculate_budget_estimate(destination, duration, budget)
        }
        travel_history.append(plan_record)

        return jsonify({
            "plan": plan_content,
            "plan_id": plan_id,
            "budget_breakdown": calculate_budget_breakdown(destination, duration, budget)
        })

    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"连接DeepSeek API失败: {e}"}), 503
    except Exception as e:
        return jsonify({"error": f"发生未知错误: {e}"}), 500

@app.route('/api/history', methods=['GET'])
def get_history():
    """获取旅行计划历史记录"""
    return jsonify({"history": travel_history})

@app.route('/api/history/<plan_id>', methods=['GET'])
def get_plan_by_id(plan_id):
    """根据ID获取特定旅行计划"""
    for plan in travel_history:
        if plan['id'] == plan_id:
            return jsonify(plan)
    return jsonify({"error": "Plan not found"}), 404

@app.route('/api/history/<plan_id>', methods=['DELETE'])
def delete_plan(plan_id):
    """删除旅行计划"""
    global travel_history
    travel_history = [plan for plan in travel_history if plan['id'] != plan_id]
    return jsonify({"message": "Plan deleted successfully"})

@app.route('/api/weather/<destination>', methods=['GET'])
def get_weather(destination):
    """获取目的地天气信息"""
    try:
        # 尝试使用免费的OpenWeatherMap API
        if WEATHER_API_KEY != "demo":
            print(f"尝试使用真实API密钥: {WEATHER_API_KEY[:10]}...")
            # 使用真实的OpenWeatherMap API
            weather_url = f"http://api.openweathermap.org/data/2.5/weather"
            params = {
                'q': destination,
                'appid': WEATHER_API_KEY,
                'units': 'metric',
                'lang': 'zh_cn'
            }
            
            response = requests.get(weather_url, params=params, timeout=10)
            print(f"天气API响应状态码: {response.status_code}")
            
            if response.status_code == 200:
                data = response.json()
                print("成功获取天气数据")
                
                # 获取天气预报
                forecast_url = f"http://api.openweathermap.org/data/2.5/forecast"
                forecast_response = requests.get(forecast_url, params=params, timeout=10)
                forecast_data = forecast_response.json() if forecast_response.status_code == 200 else None
                
                weather_data = parse_weather_data(data, forecast_data, destination)
                return jsonify(weather_data)
            else:
                print(f"天气API错误: {response.text}")
        
        print("使用智能模拟数据")
        # 如果API不可用或没有密钥，使用智能模拟数据
        weather_data = generate_smart_weather_data(destination)
        return jsonify(weather_data)
        
    except Exception as e:
        print(f"天气API异常: {str(e)}")
        # 如果所有方法都失败，返回模拟数据
        weather_data = generate_smart_weather_data(destination)
        return jsonify(weather_data)

def parse_weather_data(current_data, forecast_data, destination):
    """解析OpenWeatherMap API数据"""
    try:
        current = current_data.get('main', {})
        weather = current_data.get('weather', [{}])[0]
        
        weather_info = {
            "destination": destination,
            "current": {
                "temperature": f"{round(current.get('temp', 20))}°C",
                "condition": get_weather_condition(weather.get('main', 'Clear')),
                "humidity": f"{current.get('humidity', 65)}%",
                "wind": f"{current.get('wind', {}).get('speed', 10)} km/h"
            },
            "forecast": [],
            "recommendations": []
        }
        
        # 解析天气预报
        if forecast_data and 'list' in forecast_data:
            daily_forecasts = {}
            for item in forecast_data['list']:
                date = item['dt_txt'].split(' ')[0]
                if date not in daily_forecasts:
                    daily_forecasts[date] = {
                        'high': item['main']['temp'],
                        'low': item['main']['temp'],
                        'condition': item['weather'][0]['main']
                    }
                else:
                    daily_forecasts[date]['high'] = max(daily_forecasts[date]['high'], item['main']['temp'])
                    daily_forecasts[date]['low'] = min(daily_forecasts[date]['low'], item['main']['temp'])
            
            # 转换为前端需要的格式
            days = ['今天', '明天', '后天']
            for i, (date, forecast) in enumerate(list(daily_forecasts.items())[:3]):
                if i < len(days):
                    weather_info["forecast"].append({
                        "day": days[i],
                        "high": f"{round(forecast['high'])}°C",
                        "low": f"{round(forecast['low'])}°C",
                        "condition": get_weather_condition(forecast['condition'])
                    })
        
        # 生成建议
        weather_info["recommendations"] = generate_weather_recommendations(
            current.get('temp', 20), 
            weather.get('main', 'Clear')
        )
        
        return weather_info
        
    except Exception as e:
        # 如果解析失败，返回模拟数据
        return generate_smart_weather_data(destination)

def get_weather_condition(weather_main):
    """将英文天气状况转换为中文"""
    weather_map = {
        'Clear': '晴天',
        'Clouds': '多云',
        'Rain': '小雨',
        'Drizzle': '毛毛雨',
        'Thunderstorm': '雷阵雨',
        'Snow': '雪',
        'Mist': '薄雾',
        'Fog': '雾',
        'Haze': '霾'
    }
    return weather_map.get(weather_main, '晴天')

def generate_smart_weather_data(destination):
    """生成智能模拟天气数据"""
    # 根据目的地名称智能生成天气
    destination_lower = destination.lower()
    
    # 根据地理位置调整天气
    if any(keyword in destination_lower for keyword in ['东京', '日本', '首尔', '韩国']):
        # 东亚地区
        base_temp = random.randint(15, 25)
        conditions = ['晴天', '多云', '小雨']
    elif any(keyword in destination_lower for keyword in ['巴黎', '法国', '罗马', '意大利', '伦敦', '英国']):
        # 欧洲地区
        base_temp = random.randint(10, 20)
        conditions = ['多云', '小雨', '晴天']
    elif any(keyword in destination_lower for keyword in ['纽约', '美国', '洛杉矶', '旧金山']):
        # 北美地区
        base_temp = random.randint(15, 25)
        conditions = ['晴天', '多云', '小雨']
    elif any(keyword in destination_lower for keyword in ['悉尼', '澳大利亚', '墨尔本']):
        # 澳大利亚
        base_temp = random.randint(20, 30)
        conditions = ['晴天', '多云']
    elif any(keyword in destination_lower for keyword in ['曼谷', '泰国', '新加坡', '马来西亚']):
        # 东南亚
        base_temp = random.randint(25, 35)
        conditions = ['晴天', '雷阵雨', '多云']
    else:
        # 默认
        base_temp = random.randint(15, 25)
        conditions = ['晴天', '多云', '小雨']
    
    current_condition = random.choice(conditions)
    humidity = random.randint(50, 80)
    wind = random.randint(5, 15)
    
    # 生成三天预报
    forecast = []
    for i in range(3):
        day_temp = base_temp + random.randint(-3, 3)
        day_condition = random.choice(conditions)
        forecast.append({
            "day": ['今天', '明天', '后天'][i],
            "high": f"{day_temp + random.randint(2, 5)}°C",
            "low": f"{day_temp - random.randint(2, 5)}°C",
            "condition": day_condition
        })
    
    # 生成建议
    recommendations = generate_weather_recommendations(base_temp, current_condition)
    
    return {
        "destination": destination,
        "current": {
            "temperature": f"{base_temp}°C",
            "condition": current_condition,
            "humidity": f"{humidity}%",
            "wind": f"{wind} km/h"
        },
        "forecast": forecast,
        "recommendations": recommendations
    }

def generate_weather_recommendations(temperature, condition):
    """根据温度和天气状况生成建议"""
    recommendations = []
    
    if temperature < 10:
        recommendations.extend([
            "建议携带厚外套和保暖衣物",
            "注意防寒保暖",
            "适合室内活动"
        ])
    elif temperature < 20:
        recommendations.extend([
            "建议携带轻便外套",
            "适合户外活动",
            "注意天气变化"
        ])
    else:
        recommendations.extend([
            "建议携带轻便衣物",
            "适合户外活动",
            "注意防晒"
        ])
    
    if condition == '小雨' or condition == '毛毛雨':
        recommendations.extend([
            "建议携带雨伞或雨衣",
            "注意路面湿滑",
            "适合室内活动"
        ])
    elif condition == '雷阵雨':
        recommendations.extend([
            "建议携带雨具",
            "注意雷电安全",
            "避免户外活动"
        ])
    elif condition == '晴天':
        recommendations.extend([
            "注意防晒",
            "适合户外活动",
            "多补充水分"
        ])
    
    return recommendations[:4]  # 返回前4个建议

@app.route('/api/budget-calculator', methods=['POST'])
def calculate_budget():
    """详细的预算计算器"""
    data = request.json
    destination = data.get('destination')
    duration = data.get('duration')
    budget_level = data.get('budget_level', '中等')
    custom_budget = data.get('custom_budget')
    
    if custom_budget:
        total_budget = float(custom_budget)
    else:
        total_budget = calculate_budget_estimate(destination, duration, budget_level)
    
    breakdown = calculate_budget_breakdown(destination, duration, budget_level, total_budget)
    
    return jsonify({
        "total_budget": total_budget,
        "breakdown": breakdown,
        "daily_average": total_budget / duration if duration > 0 else 0,
        "recommendations": get_budget_recommendations(budget_level, total_budget)
    })

@app.route('/api/travel-recommendations', methods=['POST'])
def get_travel_recommendations():
    """基于用户偏好的旅行建议"""
    data = request.json
    interests = data.get('interests', '')
    budget = data.get('budget', '中等')
    duration = data.get('duration', 5)
    
    # 基于兴趣和预算推荐目的地
    recommendations = generate_destination_recommendations(interests, budget, duration)
    
    return jsonify({
        "recommendations": recommendations,
        "based_on": {
            "interests": interests,
            "budget": budget,
            "duration": duration
        }
    })

def calculate_budget_estimate(destination, duration, budget_level):
    """估算总预算"""
    base_costs = {
        "经济": {"daily": 300, "flight": 2000},
        "中等": {"daily": 500, "flight": 3000},
        "豪华": {"daily": 1000, "flight": 5000},
        "不限": {"daily": 800, "flight": 4000}
    }
    
    cost = base_costs.get(budget_level, base_costs["中等"])
    return cost["flight"] + (cost["daily"] * duration)

def calculate_budget_breakdown(destination, duration, budget_level, total_budget=None):
    """计算预算明细"""
    if total_budget is None:
        total_budget = calculate_budget_estimate(destination, duration, budget_level)
    
    template = budget_templates.get(budget_level, budget_templates["中等"])
    breakdown = {}
    
    for category, percentage in template.items():
        breakdown[category] = round(total_budget * percentage, 2)
    
    return breakdown

def get_budget_recommendations(budget_level, total_budget):
    """获取预算建议"""
    recommendations = {
        "经济": [
            "选择青年旅社或经济型酒店",
            "使用公共交通",
            "寻找当地美食街",
            "提前预订机票和酒店"
        ],
        "中等": [
            "选择舒适型酒店",
            "混合使用公共交通和出租车",
            "尝试当地特色餐厅",
            "适当安排购物时间"
        ],
        "豪华": [
            "选择高端酒店或度假村",
            "考虑包车服务",
            "预订米其林餐厅",
            "安排私人导游"
        ],
        "不限": [
            "根据心情选择住宿",
            "灵活安排交通方式",
            "体验各种美食",
            "享受个性化服务"
        ]
    }
    
    return recommendations.get(budget_level, recommendations["中等"])

def generate_destination_recommendations(interests, budget, duration):
    """生成目的地推荐"""
    # 分析用户兴趣
    interest_keywords = interests.lower()
    matched_categories = []
    
    # 匹配兴趣类别
    if any(keyword in interest_keywords for keyword in ['文化', '历史', '博物馆', '古迹']):
        matched_categories.append('文化历史')
    if any(keyword in interest_keywords for keyword in ['美食', '料理', '餐厅', '小吃']):
        matched_categories.append('美食料理')
    if any(keyword in interest_keywords for keyword in ['自然', '风景', '户外', '徒步']):
        matched_categories.append('自然风光')
    if any(keyword in interest_keywords for keyword in ['购物', '时尚', '奢侈品', '买买买']):
        matched_categories.append('购物时尚')
    if any(keyword in interest_keywords for keyword in ['海滩', '度假', '海岛', '潜水']):
        matched_categories.append('海滩度假')
    
    # 如果没有匹配到特定类别，提供通用推荐
    if not matched_categories:
        matched_categories = ['文化历史', '美食料理', '自然风光']
    
    # 收集推荐目的地
    all_recommendations = []
    for category in matched_categories:
        if category in destinations_database:
            all_recommendations.extend(destinations_database[category])
    
    # 根据预算筛选
    budget_mapping = {"经济": 1, "中等": 2, "豪华": 3}
    user_budget_level = budget_mapping.get(budget, 2)
    
    filtered_recommendations = []
    for rec in all_recommendations:
        rec_budget_level = budget_mapping.get(rec["budget_level"], 2)
        if rec_budget_level <= user_budget_level:
            filtered_recommendations.append(rec)
    
    # 去重并随机排序
    unique_recommendations = []
    seen_names = set()
    for rec in filtered_recommendations:
        if rec["name"] not in seen_names:
            unique_recommendations.append(rec)
            seen_names.add(rec["name"])
    
    # 随机选择推荐
    random.shuffle(unique_recommendations)
    return unique_recommendations[:6]  # 返回前6个推荐

if __name__ == '__main__':
    app.run(debug=True, port=5000)