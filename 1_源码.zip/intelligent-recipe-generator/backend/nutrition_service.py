import re
import json
from models import db, NutritionData

class NutritionService:
    def __init__(self):
        self.nutrition_db = self._load_nutrition_database()
    
    def _load_nutrition_database(self):
        """加载常见食材的营养数据库"""
        nutrition_data = {
            # 肉类
            "鸡肉": {"calories": 165, "protein": 31, "fat": 3.6, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 74},
            "鸡胸肉": {"calories": 165, "protein": 31, "fat": 3.6, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 74},
            "牛肉": {"calories": 250, "protein": 26, "fat": 15, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 72},
            "猪肉": {"calories": 242, "protein": 27, "fat": 14, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 62},
            "羊肉": {"calories": 294, "protein": 25, "fat": 21, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 65},
            
            # 鱼类
            "三文鱼": {"calories": 208, "protein": 25, "fat": 12, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 59},
            "鲈鱼": {"calories": 97, "protein": 20, "fat": 2.3, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 78},
            "虾": {"calories": 99, "protein": 24, "fat": 0.3, "carbs": 0.2, "fiber": 0, "sugar": 0, "sodium": 111},
            
            # 蔬菜
            "西红柿": {"calories": 18, "protein": 0.9, "fat": 0.2, "carbs": 3.9, "fiber": 1.2, "sugar": 2.6, "sodium": 5},
            "土豆": {"calories": 77, "protein": 2, "fat": 0.1, "carbs": 17, "fiber": 2.2, "sugar": 0.8, "sodium": 6},
            "胡萝卜": {"calories": 41, "protein": 0.9, "fat": 0.2, "carbs": 9.6, "fiber": 2.8, "sugar": 4.7, "sodium": 69},
            "洋葱": {"calories": 40, "protein": 1.1, "fat": 0.1, "carbs": 9.3, "fiber": 1.7, "sugar": 4.7, "sodium": 4},
            "青椒": {"calories": 20, "protein": 0.9, "fat": 0.2, "carbs": 4.6, "fiber": 1.7, "sugar": 2.4, "sodium": 4},
            "白菜": {"calories": 12, "protein": 1.2, "fat": 0.2, "carbs": 2.2, "fiber": 1.0, "sugar": 1.1, "sodium": 27},
            "菠菜": {"calories": 23, "protein": 2.9, "fat": 0.4, "carbs": 3.6, "fiber": 2.2, "sugar": 0.4, "sodium": 79},
            "西兰花": {"calories": 34, "protein": 2.8, "fat": 0.4, "carbs": 7, "fiber": 2.6, "sugar": 1.5, "sodium": 33},
            
            # 豆类
            "豆腐": {"calories": 76, "protein": 8, "fat": 4.8, "carbs": 1.9, "fiber": 0.3, "sugar": 0.6, "sodium": 7},
            "豆芽": {"calories": 30, "protein": 3, "fat": 0.2, "carbs": 5.9, "fiber": 1.8, "sugar": 4.1, "sodium": 6},
            
            # 蛋类
            "鸡蛋": {"calories": 155, "protein": 13, "fat": 11, "carbs": 1.1, "fiber": 0, "sugar": 1.1, "sodium": 124},
            
            # 谷物
            "米饭": {"calories": 130, "protein": 2.7, "fat": 0.3, "carbs": 28, "fiber": 0.4, "sugar": 0.1, "sodium": 1},
            "面条": {"calories": 138, "protein": 5, "fat": 1.1, "carbs": 25, "fiber": 1.8, "sugar": 0.4, "sodium": 5},
            "面包": {"calories": 265, "protein": 9, "fat": 3.2, "carbs": 49, "fiber": 2.7, "sugar": 5, "sodium": 491},
            
            # 调味料
            "油": {"calories": 884, "protein": 0, "fat": 100, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 0},
            "盐": {"calories": 0, "protein": 0, "fat": 0, "carbs": 0, "fiber": 0, "sugar": 0, "sodium": 38758},
            "酱油": {"calories": 60, "protein": 7, "fat": 0.1, "carbs": 5.6, "fiber": 0.8, "sugar": 0.4, "sodium": 5493},
            "醋": {"calories": 22, "protein": 0, "fat": 0, "carbs": 0.9, "fiber": 0, "sugar": 0.4, "sodium": 5},
            
            # 其他
            "蘑菇": {"calories": 22, "protein": 3.1, "fat": 0.3, "carbs": 3.3, "fiber": 1, "sugar": 1.7, "sodium": 5},
            "蒜": {"calories": 149, "protein": 6.4, "fat": 0.5, "carbs": 33, "fiber": 2.1, "sugar": 1, "sodium": 17},
            "姜": {"calories": 80, "protein": 1.8, "fat": 0.8, "carbs": 18, "fiber": 2, "sugar": 1.7, "sodium": 13},
        }
        return nutrition_data
    
    def parse_ingredients(self, ingredients_text):
        """解析食材文本，提取食材名称和数量"""
        ingredients = []
        lines = ingredients_text.split('\n')
        
        for line in lines:
            line = line.strip()
            if not line or line.startswith('#'):
                continue
                
            # 匹配格式：食材名: 数量 或 食材名 数量
            match = re.match(r'^(.+?)[:：]\s*(.+)$', line)
            if match:
                name = match.group(1).strip()
                amount = match.group(2).strip()
            else:
                # 如果没有冒号，尝试匹配数字
                parts = line.split()
                if len(parts) >= 2:
                    # 假设最后一个部分是数量
                    amount = parts[-1]
                    name = ' '.join(parts[:-1])
                else:
                    name = line
                    amount = "100g"
            
            ingredients.append({
                'name': name,
                'amount': amount,
                'weight_g': self._parse_amount_to_grams(amount)
            })
        
        return ingredients
    
    def _parse_amount_to_grams(self, amount_str):
        """将数量字符串转换为克数"""
        amount_str = amount_str.lower().strip()
        
        # 常见单位转换
        if 'g' in amount_str or '克' in amount_str:
            return float(re.findall(r'\d+', amount_str)[0])
        elif 'kg' in amount_str or '千克' in amount_str:
            return float(re.findall(r'\d+', amount_str)[0]) * 1000
        elif '个' in amount_str or '只' in amount_str:
            # 假设一个鸡蛋约50g，一个西红柿约100g等
            return float(re.findall(r'\d+', amount_str)[0]) * 50
        elif '勺' in amount_str or '匙' in amount_str:
            return float(re.findall(r'\d+', amount_str)[0]) * 15
        elif '杯' in amount_str:
            return float(re.findall(r'\d+', amount_str)[0]) * 240
        else:
            # 默认按100g处理
            numbers = re.findall(r'\d+', amount_str)
            return float(numbers[0]) if numbers else 100
    
    def calculate_nutrition(self, ingredients_text):
        """计算食谱的营养成分"""
        ingredients = self.parse_ingredients(ingredients_text)
        total_nutrition = {
            'calories': 0,
            'protein': 0,
            'fat': 0,
            'carbs': 0,
            'fiber': 0,
            'sugar': 0,
            'sodium': 0,
            'ingredients_detail': []
        }
        
        for ingredient in ingredients:
            name = ingredient['name']
            weight = ingredient['weight_g']
            
            # 查找食材的营养信息
            nutrition = self._find_ingredient_nutrition(name)
            
            if nutrition:
                # 按重量比例计算
                ratio = weight / 100
                ingredient_nutrition = {
                    'name': name,
                    'amount': ingredient['amount'],
                    'weight_g': weight,
                    'calories': nutrition['calories'] * ratio,
                    'protein': nutrition['protein'] * ratio,
                    'fat': nutrition['fat'] * ratio,
                    'carbs': nutrition['carbs'] * ratio,
                    'fiber': nutrition['fiber'] * ratio,
                    'sugar': nutrition['sugar'] * ratio,
                    'sodium': nutrition['sodium'] * ratio
                }
                
                total_nutrition['ingredients_detail'].append(ingredient_nutrition)
                
                # 累加到总量
                total_nutrition['calories'] += ingredient_nutrition['calories']
                total_nutrition['protein'] += ingredient_nutrition['protein']
                total_nutrition['fat'] += ingredient_nutrition['fat']
                total_nutrition['carbs'] += ingredient_nutrition['carbs']
                total_nutrition['fiber'] += ingredient_nutrition['fiber']
                total_nutrition['sugar'] += ingredient_nutrition['sugar']
                total_nutrition['sodium'] += ingredient_nutrition['sodium']
        
        # 四舍五入到小数点后1位
        for key in ['calories', 'protein', 'fat', 'carbs', 'fiber', 'sugar', 'sodium']:
            total_nutrition[key] = round(total_nutrition[key], 1)
        
        return total_nutrition
    
    def _find_ingredient_nutrition(self, ingredient_name):
        """查找食材的营养信息"""
        # 直接匹配
        if ingredient_name in self.nutrition_db:
            return self.nutrition_db[ingredient_name]
        
        # 模糊匹配
        for key in self.nutrition_db:
            if key in ingredient_name or ingredient_name in key:
                return self.nutrition_db[key]
        
        # 如果没有找到，返回默认值
        return {
            'calories': 50,
            'protein': 2,
            'fat': 1,
            'carbs': 8,
            'fiber': 1,
            'sugar': 2,
            'sodium': 10
        }
    
    def get_nutrition_label(self, nutrition_info):
        """生成营养标签"""
        daily_values = {
            'calories': 2000,
            'protein': 50,
            'fat': 65,
            'carbs': 300,
            'fiber': 25,
            'sugar': 50,
            'sodium': 2300
        }
        
        label = {
            'nutrition_facts': nutrition_info,
            'daily_values': daily_values,
            'percentages': {}
        }
        
        for nutrient, value in nutrition_info.items():
            if nutrient in daily_values and daily_values[nutrient] > 0:
                label['percentages'][nutrient] = round((value / daily_values[nutrient]) * 100, 1)
        
        return label
