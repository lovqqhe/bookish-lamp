#!/usr/bin/env python3
"""
API配置助手
帮助用户快速配置AI旅行规划助手的API密钥
"""

import os
import sys
from pathlib import Path

def create_env_file():
    """创建.env文件"""
    backend_dir = Path("backend")
    env_file = backend_dir / ".env"
    
    if not backend_dir.exists():
        print("❌ 错误：找不到backend文件夹")
        return False
    
    print("🔧 API配置助手")
    print("=" * 50)
    
    # 检查是否已存在.env文件
    if env_file.exists():
        print("⚠️  发现已存在的.env文件")
        response = input("是否要覆盖？(y/N): ").lower()
        if response != 'y':
            print("❌ 配置已取消")
            return False
    
    print("\n📝 请输入你的API密钥：")
    print("=" * 50)
    
    # 获取DeepSeek API密钥
    print("\n🔑 DeepSeek AI API密钥（必需）")
    print("获取地址：https://platform.deepseek.com/")
    deepseek_key = input("请输入DeepSeek API密钥: ").strip()
    
    if not deepseek_key:
        print("❌ DeepSeek API密钥是必需的！")
        return False
    
    # 获取OpenWeatherMap API密钥
    print("\n🌤️  OpenWeatherMap API密钥（可选）")
    print("获取地址：https://openweathermap.org/api")
    print("如果没有，直接按回车跳过")
    weather_key = input("请输入OpenWeatherMap API密钥: ").strip()
    
    # 生成.env文件内容
    env_content = f"""# DeepSeek AI API配置（必需）
DEEPSEEK_API_KEY={deepseek_key}

# OpenWeatherMap API配置（可选）
WEATHER_API_KEY={weather_key or 'demo'}

# Flask应用配置
FLASK_ENV=development
FLASK_DEBUG=True
"""
    
    # 写入文件
    try:
        with open(env_file, 'w', encoding='utf-8') as f:
            f.write(env_content)
        
        print("\n✅ 配置成功！")
        print(f"📁 配置文件已保存到：{env_file}")
        
        # 显示配置摘要
        print("\n📋 配置摘要：")
        print(f"   DeepSeek API: {'✅ 已配置' if deepseek_key else '❌ 未配置'}")
        print(f"   Weather API: {'✅ 已配置' if weather_key else '⚠️  使用模拟数据'}")
        
        return True
        
    except Exception as e:
        print(f"❌ 保存配置文件失败：{e}")
        return False

def test_configuration():
    """测试配置"""
    print("\n🧪 测试配置...")
    
    # 检查.env文件是否存在
    env_file = Path("backend/.env")
    if not env_file.exists():
        print("❌ 找不到.env文件，请先运行配置")
        return False
    
    # 检查环境变量
    try:
        from dotenv import load_dotenv
        load_dotenv(env_file)
        
        deepseek_key = os.getenv("DEEPSEEK_API_KEY")
        weather_key = os.getenv("WEATHER_API_KEY")
        
        print("📋 当前配置：")
        print(f"   DeepSeek API: {'✅ 已配置' if deepseek_key and deepseek_key != 'your_deepseek_api_key_here' else '❌ 未配置'}")
        print(f"   Weather API: {'✅ 已配置' if weather_key and weather_key != 'demo' and weather_key != 'your_openweathermap_api_key_here' else '⚠️  使用模拟数据'}")
        
        return True
        
    except ImportError:
        print("❌ 缺少python-dotenv包，请运行：pip install python-dotenv")
        return False
    except Exception as e:
        print(f"❌ 测试配置失败：{e}")
        return False

def show_help():
    """显示帮助信息"""
    print("""
🔧 API配置助手使用说明

使用方法：
  python setup_api.py          # 配置API密钥
  python setup_api.py test     # 测试配置
  python setup_api.py help     # 显示帮助

获取API密钥：
  1. DeepSeek AI API（必需）：
     - 访问：https://platform.deepseek.com/
     - 注册账号并创建API密钥
  
  2. OpenWeatherMap API（可选）：
     - 访问：https://openweathermap.org/api
     - 注册免费账号获取API密钥

注意事项：
  - 请妥善保管API密钥，不要分享给他人
  - .env文件包含敏感信息，不要提交到版本控制
  - 如果没有天气API密钥，系统会使用智能模拟数据
""")

def main():
    """主函数"""
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == "test":
            test_configuration()
        elif command == "help":
            show_help()
        else:
            print(f"❌ 未知命令：{command}")
            show_help()
    else:
        # 默认执行配置
        if create_env_file():
            print("\n🚀 下一步：")
            print("1. 启动后端服务：cd backend && python app.py")
            print("2. 启动前端服务：cd frontend && npm run dev")
            print("3. 访问：http://localhost:5173")

if __name__ == "__main__":
    main()
