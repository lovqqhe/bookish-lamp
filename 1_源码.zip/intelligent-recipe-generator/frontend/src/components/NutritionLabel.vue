<script setup>
import { computed } from 'vue'

const props = defineProps({
  nutrition: {
    type: Object,
    required: true
  }
})

const nutritionFacts = computed(() => props.nutrition.nutrition_facts || {})
const percentages = computed(() => props.nutrition.percentages || {})
const dailyValues = computed(() => props.nutrition.daily_values || {})

const formatValue = (value) => {
  return typeof value === 'number' ? value.toFixed(1) : value
}

const getPercentageColor = (percentage) => {
  if (percentage >= 80) return '#ff6b6b'
  if (percentage >= 60) return '#ffa726'
  if (percentage >= 40) return '#66bb6a'
  return '#42a5f5'
}
</script>

<template>
  <div class="nutrition-label card">
    <div class="nutrition-header">
      <h3 class="nutrition-title">
        <span class="title-icon">📊</span>
        营养成分表
      </h3>
      <div class="nutrition-subtitle">每份食谱的营养价值分析</div>
    </div>
    
    <div class="nutrition-content">
      <div class="nutrition-row header">
        <span class="nutrient-name">营养成分</span>
        <span class="nutrient-value">含量</span>
        <span class="nutrient-percentage">每日参考值</span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">🔥</span>
          热量
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.calories) }} 千卡</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.calories || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.calories || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.calories || 0 }}%</span>
        </span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">💪</span>
          蛋白质
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.protein) }} 克</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.protein || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.protein || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.protein || 0 }}%</span>
        </span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">🫘</span>
          脂肪
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.fat) }} 克</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.fat || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.fat || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.fat || 0 }}%</span>
        </span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">🌾</span>
          碳水化合物
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.carbs) }} 克</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.carbs || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.carbs || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.carbs || 0 }}%</span>
        </span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">🌿</span>
          膳食纤维
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.fiber) }} 克</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.fiber || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.fiber || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.fiber || 0 }}%</span>
        </span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">🍯</span>
          糖分
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.sugar) }} 克</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.sugar || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.sugar || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.sugar || 0 }}%</span>
        </span>
      </div>
      
      <div class="nutrition-row">
        <span class="nutrient-name">
          <span class="nutrient-icon">🧂</span>
          钠
        </span>
        <span class="nutrient-value">{{ formatValue(nutritionFacts.sodium) }} 毫克</span>
        <span class="nutrient-percentage">
          <div class="percentage-bar">
            <div 
              class="percentage-fill" 
              :style="{ 
                width: `${Math.min(percentages.sodium || 0, 100)}%`,
                backgroundColor: getPercentageColor(percentages.sodium || 0)
              }"
            ></div>
          </div>
          <span class="percentage-text">{{ percentages.sodium || 0 }}%</span>
        </span>
      </div>
    </div>
    
    <div class="nutrition-footer">
      <div class="footer-content">
        <div class="legend">
          <div class="legend-item">
            <div class="legend-color low"></div>
            <span>低 (0-40%)</span>
          </div>
          <div class="legend-item">
            <div class="legend-color medium"></div>
            <span>中 (40-60%)</span>
          </div>
          <div class="legend-item">
            <div class="legend-color high"></div>
            <span>高 (60-80%)</span>
          </div>
          <div class="legend-item">
            <div class="legend-color very-high"></div>
            <span>很高 (80%+)</span>
          </div>
        </div>
        <p class="disclaimer">* 每日参考值基于2000卡路里饮食</p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.nutrition-label {
  margin: 2rem 0;
  overflow: hidden;
  position: relative;
}

.nutrition-label::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 2px;
}

.nutrition-header {
  text-align: center;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid #e9ecef;
}

.nutrition-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: #2c3e50;
  margin: 0 0 0.5rem 0;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
}

.title-icon {
  font-size: 1.8rem;
}

.nutrition-subtitle {
  color: #6c757d;
  font-size: 0.9rem;
  font-weight: 500;
}

.nutrition-content {
  margin-bottom: 2rem;
}

.nutrition-row {
  display: grid;
  grid-template-columns: 2fr 1fr 1.5fr;
  gap: 1rem;
  padding: 1rem 0;
  border-bottom: 1px solid #f8f9fa;
  align-items: center;
  transition: background-color 0.2s ease;
}

.nutrition-row:hover {
  background-color: rgba(102, 126, 234, 0.05);
  border-radius: 8px;
  padding: 1rem;
  margin: 0 -1rem;
}

.nutrition-row:last-child {
  border-bottom: none;
}

.nutrition-row.header {
  font-weight: 700;
  color: #2c3e50;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  margin: -1.5rem -1.5rem 1rem -1.5rem;
  padding: 1rem 1.5rem;
  border-radius: 12px 12px 0 0;
  border-bottom: none;
}

.nutrition-row.header:hover {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  margin: -1.5rem -1.5rem 1rem -1.5rem;
  padding: 1rem 1.5rem;
}

.nutrient-name {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  color: #2c3e50;
}

.nutrient-icon {
  font-size: 1.2rem;
  width: 24px;
  text-align: center;
}

.nutrient-value {
  font-weight: 600;
  color: #495057;
  text-align: center;
}

.nutrient-percentage {
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.percentage-bar {
  flex: 1;
  height: 8px;
  background-color: #e9ecef;
  border-radius: 4px;
  overflow: hidden;
  position: relative;
}

.percentage-fill {
  height: 100%;
  border-radius: 4px;
  transition: width 0.6s ease, background-color 0.3s ease;
  position: relative;
}

.percentage-fill::after {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.3), transparent);
  animation: shimmer 2s infinite;
}

@keyframes shimmer {
  0% {
    transform: translateX(-100%);
  }
  100% {
    transform: translateX(100%);
  }
}

.percentage-text {
  font-weight: 600;
  color: #495057;
  min-width: 40px;
  text-align: right;
}

.nutrition-footer {
  background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
  margin: 0 -1.5rem -1.5rem -1.5rem;
  padding: 1.5rem;
  border-radius: 0 0 12px 12px;
}

.footer-content {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.legend {
  display: flex;
  justify-content: center;
  gap: 1.5rem;
  flex-wrap: wrap;
}

.legend-item {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.8rem;
  color: #6c757d;
}

.legend-color {
  width: 12px;
  height: 12px;
  border-radius: 2px;
}

.legend-color.low {
  background-color: #42a5f5;
}

.legend-color.medium {
  background-color: #66bb6a;
}

.legend-color.high {
  background-color: #ffa726;
}

.legend-color.very-high {
  background-color: #ff6b6b;
}

.disclaimer {
  text-align: center;
  font-size: 0.8rem;
  color: #6c757d;
  margin: 0;
  font-style: italic;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .nutrition-row {
    grid-template-columns: 1fr;
    gap: 0.5rem;
    text-align: center;
  }
  
  .nutrition-row.header {
    grid-template-columns: 1fr;
  }
  
  .nutrient-percentage {
    flex-direction: column;
    gap: 0.25rem;
  }
  
  .legend {
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
  }
  
  .legend-item {
    font-size: 0.7rem;
  }
}

/* 深色模式适配 */
@media (prefers-color-scheme: dark) {
  .nutrition-title {
    color: #e1e8ed;
  }
  
  .nutrition-subtitle {
    color: #a0a0a0;
  }
  
  .nutrient-name {
    color: #e1e8ed;
  }
  
  .nutrient-value {
    color: #c0c0c0;
  }
  
  .percentage-text {
    color: #c0c0c0;
  }
  
  .nutrition-row:hover {
    background-color: rgba(102, 126, 234, 0.1);
  }
  
  .nutrition-footer {
    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
  }
  
  .legend-item {
    color: #a0a0a0;
  }
  
  .disclaimer {
    color: #808080;
  }
}
</style>
