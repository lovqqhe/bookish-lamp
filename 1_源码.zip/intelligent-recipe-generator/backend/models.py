from flask_sqlalchemy import SQLAlchemy
from flask_login import UserMixin
from datetime import datetime
import json

db = SQLAlchemy()

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(120), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关联关系
    favorites = db.relationship('Favorite', backref='user', lazy=True, cascade='all, delete-orphan')
    recipe_history = db.relationship('RecipeHistory', backref='user', lazy=True, cascade='all, delete-orphan')

class Recipe(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text)
    ingredients = db.Column(db.Text, nullable=False)  # JSON格式存储
    instructions = db.Column(db.Text, nullable=False)
    cooking_time = db.Column(db.Integer)  # 分钟
    difficulty = db.Column(db.String(20))  # 简单/中等/困难
    cuisine_type = db.Column(db.String(50))  # 中餐/西餐/日料等
    meal_type = db.Column(db.String(50))  # 早餐/午餐/晚餐/小食
    nutrition_info = db.Column(db.Text)  # JSON格式存储营养信息
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 关联关系
    favorites = db.relationship('Favorite', backref='recipe', lazy=True, cascade='all, delete-orphan')
    history = db.relationship('RecipeHistory', backref='recipe', lazy=True, cascade='all, delete-orphan')

class Favorite(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipe.id'), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # 确保用户不能重复收藏同一食谱
    __table_args__ = (db.UniqueConstraint('user_id', 'recipe_id', name='_user_recipe_uc'),)

class RecipeHistory(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    recipe_id = db.Column(db.Integer, db.ForeignKey('recipe.id'), nullable=False)
    generated_recipe = db.Column(db.Text, nullable=False)  # 存储生成的完整食谱
    ingredients_input = db.Column(db.Text, nullable=False)  # 用户输入的食材
    preferences = db.Column(db.String(200))
    meal_type = db.Column(db.String(50))
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

# 营养信息计算相关的数据模型
class NutritionData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    ingredient_name = db.Column(db.String(100), nullable=False)
    calories_per_100g = db.Column(db.Float)
    protein_per_100g = db.Column(db.Float)
    fat_per_100g = db.Column(db.Float)
    carbs_per_100g = db.Column(db.Float)
    fiber_per_100g = db.Column(db.Float)
    sugar_per_100g = db.Column(db.Float)
    sodium_per_100g = db.Column(db.Float)
    
    def to_dict(self):
        return {
            'ingredient_name': self.ingredient_name,
            'calories_per_100g': self.calories_per_100g,
            'protein_per_100g': self.protein_per_100g,
            'fat_per_100g': self.fat_per_100g,
            'carbs_per_100g': self.carbs_per_100g,
            'fiber_per_100g': self.fiber_per_100g,
            'sugar_per_100g': self.sugar_per_100g,
            'sodium_per_100g': self.sodium_per_100g
        }
