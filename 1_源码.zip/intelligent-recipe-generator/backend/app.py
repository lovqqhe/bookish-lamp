import os
import requests
import json
import re
from flask import Flask, request, jsonify, session
from flask_cors import CORS
from flask_login import LoginManager, login_user, logout_user, login_required, current_user
from flask_bcrypt import Bcrypt
from dotenv import load_dotenv
from models import db, User, Recipe, Favorite, RecipeHistory, NutritionData
from nutrition_service import NutritionService

# 加载 .env 文件中的环境变量
load_dotenv()

app = Flask(__name__)
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY', 'your-secret-key-here')
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///recipes.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

# 初始化扩展
db.init_app(app)
bcrypt = Bcrypt(app)
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# 允许来自前端开发服务器的跨域请求
CORS(app, resources={r"/api/*": {"origins": "http://localhost:5173"}}, supports_credentials=True)

DEEPSEEK_API_KEY = os.getenv("DEEPSEEK_API_KEY")
DEEPSEEK_API_URL = "https://api.deepseek.com/chat/completions"

# 初始化营养计算服务
nutrition_service = NutritionService()

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# 创建数据库表
def create_tables():
    with app.app_context():
        try:
            print("正在创建数据库表...")
            db.create_all()
            print("数据库表创建成功！")
            # 初始化一些示例数据
            init_sample_data()
        except Exception as e:
            print(f"创建数据库表时出错: {e}")
            import traceback
            traceback.print_exc()

def init_sample_data():
    """初始化示例数据"""
    try:
        # 检查是否已经有数据
        if User.query.first() is None:
            print("正在创建示例用户...")
            # 创建示例用户
            hashed_password = bcrypt.generate_password_hash('password123').decode('utf-8')
            user = User(username='demo', email='demo@example.com', password_hash=hashed_password)
            db.session.add(user)
            db.session.commit()
            print("示例用户创建成功: demo / password123")
    except Exception as e:
        print(f"初始化示例数据时出错: {e}")
        db.session.rollback()

@app.route('/api/register', methods=['POST'])
def register():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "无效的请求数据"}), 400
            
        username = data.get('username')
        email = data.get('email')
        password = data.get('password')
        
        if not all([username, email, password]):
            return jsonify({"error": "所有字段都是必需的"}), 400
        
        # 检查用户是否已存在
        if User.query.filter_by(username=username).first():
            return jsonify({"error": "用户名已存在"}), 400
        
        if User.query.filter_by(email=email).first():
            return jsonify({"error": "邮箱已存在"}), 400
        
        # 创建新用户
        hashed_password = bcrypt.generate_password_hash(password).decode('utf-8')
        user = User(username=username, email=email, password_hash=hashed_password)
        db.session.add(user)
        db.session.commit()
        
        return jsonify({"message": "注册成功"}), 201
    except Exception as e:
        db.session.rollback()
        print(f"注册错误: {e}")
        return jsonify({"error": "注册失败，请稍后重试"}), 500

@app.route('/api/login', methods=['POST'])
def login():
    try:
        data = request.json
        if not data:
            return jsonify({"error": "无效的请求数据"}), 400
            
        username = data.get('username')
        password = data.get('password')
        
        if not username or not password:
            return jsonify({"error": "用户名和密码都是必需的"}), 400
        
        user = User.query.filter_by(username=username).first()
        
        if user and bcrypt.check_password_hash(user.password_hash, password):
            login_user(user)
            return jsonify({
                "message": "登录成功",
                "user": {
                    "id": user.id,
                    "username": user.username,
                    "email": user.email
                }
            })
        
        return jsonify({"error": "用户名或密码错误"}), 401
    except Exception as e:
        print(f"登录错误: {e}")
        return jsonify({"error": "登录失败，请稍后重试"}), 500

@app.route('/api/logout', methods=['POST'])
@login_required
def logout():
    logout_user()
    return jsonify({"message": "登出成功"})

@app.route('/api/user/profile', methods=['GET'])
@login_required
def get_user_profile():
    return jsonify({
        "id": current_user.id,
        "username": current_user.username,
        "email": current_user.email,
        "created_at": current_user.created_at.isoformat()
    })

@app.route('/api/generate-recipe', methods=['POST'])
def generate_recipe():
    if not DEEPSEEK_API_KEY:
        return jsonify(
            {"error": "DeepSeek API key not found. Please set the DEEPSEEK_API_KEY environment variable."}), 500

    data = request.json
    ingredients = data.get('ingredients')
    preferences = data.get('preferences', '无特殊要求')
    meal_type = data.get('mealType', '不限')

    if not ingredients:
        return jsonify({"error": "Ingredients are required."}), 400

    # 改进的AI Prompt，包含更多分类信息
    prompt = f"""
    你是一位富有创意的顶级厨师。请根据用户提供的以下信息，生成一份详细、美味且易于操作的食谱。

    **用户信息:**
    - **现有食材:** {ingredients}
    - **口味偏好或饮食要求:** {preferences}
    - **期望餐类型:** {meal_type}

    **输出要求:**
    请严格按照下面的Markdown格式返回食谱，不要包含任何额外的介绍或结尾语。

    # [食谱名称]

    ## 简介
    一小段吸引人的食谱描述。

    ## 基本信息
    - **菜系类型:** [中餐/西餐/日料/韩料/东南亚/其他]
    - **难度等级:** [简单/中等/困难]
    - **烹饪时间:** [分钟数]
    - **适合餐次:** [早餐/午餐/晚餐/小食]

    ## 准备材料
    - 食材1: 数量 (例如: 鸡蛋: 2个)
    - 食材2: 数量
    ...

    ## 烹饪步骤
    1. 步骤一的详细说明。
    2. 步骤二的详细说明。
    3. ...

    ## 小贴士
    - 一些让菜肴更美味的小建议。
    """

    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {DEEPSEEK_API_KEY}"
    }

    payload = {
        "model": "deepseek-chat",
        "messages": [
            {"role": "system", "content": "你是一位富有创意的顶级厨师。"},
            {"role": "user", "content": prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 1500,
        "stream": False
    }

    try:
        response = requests.post(DEEPSEEK_API_URL, headers=headers, json=payload, timeout=120)
        response.raise_for_status()

        result = response.json()
        recipe_content = result['choices'][0]['message']['content']

        # 解析食谱内容，提取结构化信息
        recipe_info = parse_recipe_content(recipe_content)
        
        # 计算营养信息
        nutrition_info = nutrition_service.calculate_nutrition(recipe_info.get('ingredients', ''))
        nutrition_label = nutrition_service.get_nutrition_label(nutrition_info)

        # 如果用户已登录，保存到历史记录
        if current_user.is_authenticated:
            save_recipe_history(recipe_content, ingredients, preferences, meal_type)

        return jsonify({
            "recipe": recipe_content,
            "recipe_info": recipe_info,
            "nutrition": nutrition_label
        })

    except requests.exceptions.RequestException as e:
        return jsonify({"error": f"Failed to connect to DeepSeek API: {e}"}), 503
    except Exception as e:
        return jsonify({"error": f"An unexpected error occurred: {e}"}), 500

def parse_recipe_content(recipe_content):
    """解析食谱内容，提取结构化信息"""
    info = {
        'title': '',
        'cuisine_type': '',
        'difficulty': '',
        'cooking_time': 0,
        'meal_type': '',
        'ingredients': ''
    }
    
    lines = recipe_content.split('\n')
    current_section = ''
    
    for line in lines:
        line = line.strip()
        
        # 提取标题
        if line.startswith('# '):
            info['title'] = line[2:].strip()
        
        # 提取基本信息
        elif '菜系类型:' in line:
            info['cuisine_type'] = line.split('菜系类型:')[1].strip().strip('[]')
        elif '难度等级:' in line:
            info['difficulty'] = line.split('难度等级:')[1].strip().strip('[]')
        elif '烹饪时间:' in line:
            time_str = line.split('烹饪时间:')[1].strip().strip('[]')
            info['cooking_time'] = int(re.findall(r'\d+', time_str)[0]) if re.findall(r'\d+', time_str) else 0
        elif '适合餐次:' in line:
            info['meal_type'] = line.split('适合餐次:')[1].strip().strip('[]')
        
        # 提取食材
        elif line.startswith('## 准备材料'):
            current_section = 'ingredients'
        elif current_section == 'ingredients' and line.startswith('-'):
            if info['ingredients']:
                info['ingredients'] += '\n'
            info['ingredients'] += line[1:].strip()
        elif line.startswith('##') and current_section == 'ingredients':
            current_section = ''
    
    return info

def save_recipe_history(recipe_content, ingredients_input, preferences, meal_type):
    """保存食谱到历史记录"""
    try:
        # 创建食谱记录
        recipe_info = parse_recipe_content(recipe_content)
        recipe = Recipe(
            title=recipe_info['title'],
            description=recipe_content,
            ingredients=recipe_info['ingredients'],
            instructions=recipe_content,
            cooking_time=recipe_info['cooking_time'],
            difficulty=recipe_info['difficulty'],
            cuisine_type=recipe_info['cuisine_type'],
            meal_type=recipe_info['meal_type']
        )
        db.session.add(recipe)
        db.session.flush()  # 获取recipe.id
        
        # 创建历史记录
        history = RecipeHistory(
            user_id=current_user.id,
            recipe_id=recipe.id,
            generated_recipe=recipe_content,
            ingredients_input=ingredients_input,
            preferences=preferences,
            meal_type=meal_type
        )
        db.session.add(history)
        db.session.commit()
    except Exception as e:
        print(f"Error saving recipe history: {e}")
        db.session.rollback()

@app.route('/api/favorites', methods=['GET'])
@login_required
def get_favorites():
    """获取用户的收藏食谱"""
    favorites = Favorite.query.filter_by(user_id=current_user.id).all()
    favorite_recipes = []
    
    for fav in favorites:
        recipe = Recipe.query.get(fav.recipe_id)
        if recipe:
            favorite_recipes.append({
                'id': recipe.id,
                'title': recipe.title,
                'cuisine_type': recipe.cuisine_type,
                'difficulty': recipe.difficulty,
                'cooking_time': recipe.cooking_time,
                'created_at': fav.created_at.isoformat()
            })
    
    return jsonify(favorite_recipes)

@app.route('/api/favorites/<int:recipe_id>', methods=['POST'])
@login_required
def add_favorite(recipe_id):
    """添加食谱到收藏"""
    # 检查食谱是否存在
    recipe = Recipe.query.get(recipe_id)
    if not recipe:
        return jsonify({"error": "食谱不存在"}), 404
    
    # 检查是否已经收藏
    existing_favorite = Favorite.query.filter_by(
        user_id=current_user.id, 
        recipe_id=recipe_id
    ).first()
    
    if existing_favorite:
        return jsonify({"error": "已经收藏过这个食谱"}), 400
    
    # 添加收藏
    favorite = Favorite(user_id=current_user.id, recipe_id=recipe_id)
    db.session.add(favorite)
    db.session.commit()
    
    return jsonify({"message": "收藏成功"})

@app.route('/api/favorites/<int:recipe_id>', methods=['DELETE'])
@login_required
def remove_favorite(recipe_id):
    """取消收藏"""
    favorite = Favorite.query.filter_by(
        user_id=current_user.id, 
        recipe_id=recipe_id
    ).first()
    
    if not favorite:
        return jsonify({"error": "未找到收藏记录"}), 404
    
    db.session.delete(favorite)
    db.session.commit()
    
    return jsonify({"message": "取消收藏成功"})

@app.route('/api/history', methods=['GET'])
@login_required
def get_history():
    """获取用户的食谱历史"""
    history = RecipeHistory.query.filter_by(user_id=current_user.id).order_by(RecipeHistory.created_at.desc()).all()
    
    history_list = []
    for record in history:
        recipe = Recipe.query.get(record.recipe_id)
        if recipe:
            history_list.append({
                'id': record.id,
                'recipe_id': record.recipe_id,
                'title': recipe.title,
                'ingredients_input': record.ingredients_input,
                'preferences': record.preferences,
                'meal_type': record.meal_type,
                'created_at': record.created_at.isoformat()
            })
    
    return jsonify(history_list)

@app.route('/api/search', methods=['GET'])
def search_recipes():
    """搜索食谱"""
    query = request.args.get('q', '')
    cuisine_type = request.args.get('cuisine_type', '')
    difficulty = request.args.get('difficulty', '')
    meal_type = request.args.get('meal_type', '')
    
    # 构建查询
    recipes_query = Recipe.query
    
    if query:
        recipes_query = recipes_query.filter(
            Recipe.title.contains(query) | 
            Recipe.description.contains(query)
        )
    
    if cuisine_type:
        recipes_query = recipes_query.filter(Recipe.cuisine_type == cuisine_type)
    
    if difficulty:
        recipes_query = recipes_query.filter(Recipe.difficulty == difficulty)
    
    if meal_type:
        recipes_query = recipes_query.filter(Recipe.meal_type == meal_type)
    
    recipes = recipes_query.order_by(Recipe.created_at.desc()).limit(20).all()
    
    results = []
    for recipe in recipes:
        results.append({
            'id': recipe.id,
            'title': recipe.title,
            'cuisine_type': recipe.cuisine_type,
            'difficulty': recipe.difficulty,
            'cooking_time': recipe.cooking_time,
            'meal_type': recipe.meal_type,
            'created_at': recipe.created_at.isoformat()
        })
    
    return jsonify(results)

@app.route('/api/recipe/<int:recipe_id>', methods=['GET'])
def get_recipe(recipe_id):
    """获取单个食谱详情"""
    recipe = Recipe.query.get(recipe_id)
    if not recipe:
        return jsonify({"error": "食谱不存在"}), 404
    
    # 检查是否已收藏
    is_favorited = False
    if current_user.is_authenticated:
        favorite = Favorite.query.filter_by(
            user_id=current_user.id, 
            recipe_id=recipe_id
        ).first()
        is_favorited = favorite is not None
    
    # 计算营养信息
    nutrition_info = nutrition_service.calculate_nutrition(recipe.ingredients)
    nutrition_label = nutrition_service.get_nutrition_label(nutrition_info)
    
    return jsonify({
        'id': recipe.id,
        'title': recipe.title,
        'description': recipe.description,
        'ingredients': recipe.ingredients,
        'instructions': recipe.instructions,
        'cooking_time': recipe.cooking_time,
        'difficulty': recipe.difficulty,
        'cuisine_type': recipe.cuisine_type,
        'meal_type': recipe.meal_type,
        'nutrition': nutrition_label,
        'is_favorited': is_favorited,
        'created_at': recipe.created_at.isoformat()
    })

@app.route('/api/categories', methods=['GET'])
def get_categories():
    """获取所有分类选项"""
    return jsonify({
        'cuisine_types': ['中餐', '西餐', '日料', '韩料', '东南亚', '其他'],
        'difficulties': ['简单', '中等', '困难'],
        'meal_types': ['早餐', '午餐', '晚餐', '小食']
    })

if __name__ == '__main__':
    create_tables()
    app.run(debug=True, port=5000)