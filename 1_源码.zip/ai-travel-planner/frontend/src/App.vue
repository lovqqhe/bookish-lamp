<script setup>
import { ref, onMounted } from 'vue';
import PlanDisplay from './components/PlanDisplay.vue';

const destination = ref('法国巴黎');
const duration = ref(5);
const interests = ref('历史文化, 艺术博物馆, 美食探索, 悠闲漫步');
const budget = ref('中等');

const generatedPlan = ref('');
const isLoading = ref(false);
const error = ref(null);
const currentPlanId = ref(null);
const budgetBreakdown = ref(null);

// 新增状态
const activeTab = ref('plan'); // plan, history, budget, weather, recommendations
const travelHistory = ref([]);
const weatherData = ref(null);
const recommendations = ref([]);
const showBudgetCalculator = ref(false);
const customBudget = ref('');
const selectedPlanDetail = ref(null);
const showPlanDetail = ref(false);

async function generatePlan() {
  isLoading.value = true;
  error.value = null;
  generatedPlan.value = '';
  budgetBreakdown.value = null;

  try {
    const response = await fetch('http://localhost:5000/api/generate-plan', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        destination: destination.value,
        duration: duration.value,
        interests: interests.value,
        budget: budget.value,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `HTTP错误! 状态码: ${response.status}`);
    }

    const data = await response.json();
    generatedPlan.value = data.plan;
    currentPlanId.value = data.plan_id;
    budgetBreakdown.value = data.budget_breakdown;
    
    // 自动切换到计划显示
    activeTab.value = 'plan';
    
    // 刷新历史记录
    await loadHistory();
  } catch (e) {
    console.error('生成计划时出错:', e);
    error.value = `生成失败: ${e.message}。请检查后端服务是否运行以及API密钥是否正确。`;
  } finally {
    isLoading.value = false;
  }
}

async function loadHistory() {
  try {
    const response = await fetch('http://localhost:5000/api/history');
    if (response.ok) {
      const data = await response.json();
      travelHistory.value = data.history;
    }
  } catch (e) {
    console.error('加载历史记录失败:', e);
  }
}

async function deletePlan(planId) {
  try {
    const response = await fetch(`http://localhost:5000/api/history/${planId}`, {
      method: 'DELETE'
    });
    if (response.ok) {
      await loadHistory();
      if (currentPlanId.value === planId) {
        generatedPlan.value = '';
        currentPlanId.value = null;
        budgetBreakdown.value = null;
      }
    }
  } catch (e) {
    console.error('删除计划失败:', e);
  }
}

async function viewPlanDetail(planId) {
  try {
    const response = await fetch(`http://localhost:5000/api/history/${planId}`);
    if (response.ok) {
      const planData = await response.json();
      selectedPlanDetail.value = planData;
      showPlanDetail.value = true;
    }
  } catch (e) {
    console.error('获取计划详情失败:', e);
  }
}

function closePlanDetail() {
  showPlanDetail.value = false;
  selectedPlanDetail.value = null;
}

async function loadWeather() {
  if (!destination.value) return;
  
  try {
    const response = await fetch(`http://localhost:5000/api/weather/${encodeURIComponent(destination.value)}`);
    if (response.ok) {
      weatherData.value = await response.json();
    }
  } catch (e) {
    console.error('获取天气信息失败:', e);
  }
}

async function getRecommendations() {
  try {
    const response = await fetch('http://localhost:5000/api/travel-recommendations', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        interests: interests.value,
        budget: budget.value,
        duration: duration.value,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      recommendations.value = data.recommendations;
    }
  } catch (e) {
    console.error('获取推荐失败:', e);
  }
}

async function calculateBudget() {
  try {
    const response = await fetch('http://localhost:5000/api/budget-calculator', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        destination: destination.value,
        duration: duration.value,
        budget_level: budget.value,
        custom_budget: customBudget.value || null,
      }),
    });

    if (response.ok) {
      const data = await response.json();
      budgetBreakdown.value = data;
    }
  } catch (e) {
    console.error('计算预算失败:', e);
  }
}

function exportPlan(planData = null) {
  const planToExport = planData || generatedPlan.value;
  const destinationToExport = planData ? planData.destination : destination.value;
  const budgetToExport = planData ? planData.total_budget : budgetBreakdown.value;
  
  if (!planToExport) return;
  
  // 创建可打印的HTML内容
  const printContent = `
    <html>
      <head>
        <title>${destinationToExport} 旅行计划</title>
        <style>
          body { font-family: Arial, sans-serif; margin: 20px; }
          h1 { color: #2c3e50; text-align: center; }
          h2 { color: #0056b3; border-bottom: 2px solid #e0e0e0; }
          h3 { color: #343a40; }
          ul { padding-left: 20px; }
          li { margin-bottom: 8px; }
          .budget { background: #f8f9fa; padding: 15px; border-radius: 8px; margin: 20px 0; }
          .plan-info { background: #e9ecef; padding: 15px; border-radius: 8px; margin: 20px 0; }
        </style>
      </head>
      <body>
        <h1>${destinationToExport} 旅行计划</h1>
        ${planData ? `
        <div class="plan-info">
          <p><strong>兴趣偏好:</strong> ${planData.interests}</p>
          <p><strong>预算水平:</strong> ${planData.budget}</p>
          <p><strong>创建时间:</strong> ${new Date(planData.created_at).toLocaleString()}</p>
          <p><strong>总预算:</strong> ¥${planData.total_budget}</p>
        </div>
        ` : ''}
        <div id="plan-content">${planToExport}</div>
        ${budgetToExport ? `
        <div class="budget">
          <h3>预算明细</h3>
          <ul>
            ${typeof budgetToExport === 'object' ? 
              Object.entries(budgetToExport).map(([category, amount]) => 
                `<li><strong>${category}:</strong> ¥${amount}</li>`
              ).join('') :
              `<li><strong>总预算:</strong> ¥${budgetToExport}</li>`
            }
          </ul>
        </div>
        ` : ''}
      </body>
    </html>
  `;
  
  const printWindow = window.open('', '_blank');
  printWindow.document.write(printContent);
  printWindow.document.close();
  printWindow.print();
}

function selectDestination(rec) {
  destination.value = rec.name;
  budget.value = rec.budget_level;
  activeTab.value = 'plan';
}

onMounted(() => {
  loadHistory();
});
</script>

<template>
  <div id="app-container">
    <header>
      <h1>旅行计划 AI 助手 ✈️</h1>
      <p class="subtitle">输入你的梦想之旅，让 DeepSeek AI 为你规划</p>
    </header>

    <!-- 导航标签 -->
    <nav class="tab-navigation">
      <button 
        :class="{ active: activeTab === 'plan' }" 
        @click="activeTab = 'plan'"
      >
        🗺️ 生成计划
      </button>
      <button 
        :class="{ active: activeTab === 'history' }" 
        @click="activeTab = 'history'"
      >
        📚 历史记录
      </button>
      <button 
        :class="{ active: activeTab === 'budget' }" 
        @click="activeTab = 'budget'"
      >
        💰 预算计算
      </button>
      <button 
        :class="{ active: activeTab === 'weather' }" 
        @click="activeTab = 'weather'; loadWeather()"
      >
        🌤️ 天气信息
      </button>
      <button 
        :class="{ active: activeTab === 'recommendations' }" 
        @click="activeTab = 'recommendations'; getRecommendations()"
      >
        🎯 旅行推荐
      </button>
    </nav>

    <main>
      <!-- 生成计划标签页 -->
      <div v-if="activeTab === 'plan'" class="tab-content">
        <div class="form-card">
          <div class="grid-container">
            <div class="form-group">
              <label for="destination">目的地</label>
              <input type="text" id="destination" v-model="destination" placeholder="例如: 日本东京">
            </div>
            <div class="form-group">
              <label for="duration">旅行天数</label>
              <input type="number" id="duration" v-model="duration" min="1" max="30">
            </div>
            <div class="form-group">
              <label for="budget">预算水平</label>
              <select id="budget" v-model="budget">
                <option>经济</option>
                <option>中等</option>
                <option>豪华</option>
                <option>不限</option>
              </select>
            </div>
            <div class="form-group full-width">
              <label for="interests">兴趣与偏好 (描述越详细，计划越精彩)</label>
              <textarea id="interests" v-model="interests" rows="3" placeholder="例如: 喜欢自然风光, 对科技馆感兴趣, 想体验当地特色小吃, 节奏慢一点"></textarea>
            </div>
          </div>
          <button @click="generatePlan" :disabled="isLoading">
            {{ isLoading ? 'AI正在规划中...' : '🚀 生成专属旅行计划' }}
          </button>
        </div>

        <div class="result-container">
          <div v-if="isLoading" class="loading-spinner">
            <div class="spinner"></div>
            <p>AI规划师正在为您绘制旅行蓝图...</p>
          </div>
          <div v-if="error" class="error-message">
            <p>{{ error }}</p>
          </div>
          <div v-if="generatedPlan && !isLoading" class="plan-actions">
            <button @click="exportPlan" class="export-btn">📄 导出计划</button>
          </div>
          <PlanDisplay :planMarkdown="generatedPlan" v-if="generatedPlan && !isLoading" />
          <div v-if="!generatedPlan && !isLoading && !error" class="placeholder">
            <p>你的下一次冒险，从这里开始！</p>
          </div>
        </div>
      </div>

      <!-- 历史记录标签页 -->
      <div v-if="activeTab === 'history'" class="tab-content">
        <div class="history-container">
          <h2>旅行计划历史</h2>
          <div v-if="travelHistory.length === 0" class="empty-history">
            <p>还没有生成过旅行计划</p>
          </div>
          <div v-else class="history-list">
            <div v-for="plan in travelHistory" :key="plan.id" class="history-item">
              <div class="history-header">
                <h3>{{ plan.destination }} - {{ plan.duration }}天</h3>
                <div class="history-actions">
                  <button @click="viewPlanDetail(plan.id)" class="view-btn">👁️ 查看详情</button>
                  <button @click="deletePlan(plan.id)" class="delete-btn">🗑️</button>
                </div>
              </div>
              <div class="history-details">
                <p><strong>兴趣:</strong> {{ plan.interests }}</p>
                <p><strong>预算:</strong> {{ plan.budget }}</p>
                <p><strong>创建时间:</strong> {{ new Date(plan.created_at).toLocaleString() }}</p>
                <p><strong>总预算:</strong> ¥{{ plan.total_budget }}</p>
              </div>
              <div class="history-preview">
                <PlanDisplay :planMarkdown="plan.plan.substring(0, 200) + '...'" />
              </div>
            </div>
          </div>
        </div>
      </div>

      <!-- 计划详情模态框 -->
      <div v-if="showPlanDetail && selectedPlanDetail" class="plan-detail-modal">
        <div class="modal-overlay" @click="closePlanDetail"></div>
        <div class="modal-content">
          <div class="modal-header">
            <h2>{{ selectedPlanDetail.destination }} - {{ selectedPlanDetail.duration }}天 旅行计划</h2>
            <button @click="closePlanDetail" class="close-btn">✕</button>
          </div>
          <div class="modal-body">
            <div class="plan-info">
              <p><strong>兴趣偏好:</strong> {{ selectedPlanDetail.interests }}</p>
              <p><strong>预算水平:</strong> {{ selectedPlanDetail.budget }}</p>
              <p><strong>创建时间:</strong> {{ new Date(selectedPlanDetail.created_at).toLocaleString() }}</p>
              <p><strong>总预算:</strong> ¥{{ selectedPlanDetail.total_budget }}</p>
            </div>
            <div class="plan-content">
              <PlanDisplay :planMarkdown="selectedPlanDetail.plan" />
            </div>
          </div>
          <div class="modal-footer">
            <button @click="exportPlan(selectedPlanDetail)" class="export-btn">📄 导出计划</button>
            <button @click="closePlanDetail" class="close-modal-btn">关闭</button>
          </div>
        </div>
      </div>

      <!-- 预算计算标签页 -->
      <div v-if="activeTab === 'budget'" class="tab-content">
        <div class="budget-calculator">
          <h2>预算计算器</h2>
          <div class="budget-form">
            <div class="form-group">
              <label>目的地</label>
              <input type="text" v-model="destination" placeholder="输入目的地">
            </div>
            <div class="form-group">
              <label>旅行天数</label>
              <input type="number" v-model="duration" min="1" max="30">
            </div>
            <div class="form-group">
              <label>预算水平</label>
              <select v-model="budget">
                <option>经济</option>
                <option>中等</option>
                <option>豪华</option>
                <option>不限</option>
              </select>
            </div>
            <div class="form-group">
              <label>自定义预算 (可选)</label>
              <input type="number" v-model="customBudget" placeholder="输入总预算金额">
            </div>
            <button @click="calculateBudget">计算预算</button>
          </div>

          <div v-if="budgetBreakdown && typeof budgetBreakdown === 'object' && 'breakdown' in budgetBreakdown" class="budget-results">
            <h3>预算明细</h3>
            <div class="budget-summary">
              <div class="total-budget">
                <h4>总预算: ¥{{ budgetBreakdown.total_budget }}</h4>
                <p>日均: ¥{{ budgetBreakdown.daily_average }}</p>
              </div>
              <div class="budget-chart">
                <div v-for="(amount, category) in budgetBreakdown.breakdown" :key="category" class="budget-item">
                  <div class="budget-label">{{ category }}</div>
                  <div class="budget-bar">
                    <div class="budget-fill" :style="{ width: (amount / budgetBreakdown.total_budget * 100) + '%' }"></div>
                  </div>
                  <div class="budget-amount">¥{{ amount }}</div>
                </div>
              </div>
            </div>
            <div class="budget-recommendations">
              <h4>预算建议</h4>
              <ul>
                <li v-for="rec in budgetBreakdown.recommendations" :key="rec">{{ rec }}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- 天气信息标签页 -->
      <div v-if="activeTab === 'weather'" class="tab-content">
        <div class="weather-container">
          <h2>天气信息</h2>
          <div class="weather-form">
            <input type="text" v-model="destination" placeholder="输入目的地">
            <button @click="loadWeather">查询天气</button>
          </div>
          
          <div v-if="weatherData" class="weather-info">
            <h3>{{ weatherData.destination }} 天气</h3>
            <div class="current-weather">
              <div class="weather-main">
                <h4>当前天气</h4>
                <div class="weather-details">
                  <p><strong>温度:</strong> {{ weatherData.current.temperature }}</p>
                  <p><strong>天气:</strong> {{ weatherData.current.condition }}</p>
                  <p><strong>湿度:</strong> {{ weatherData.current.humidity }}</p>
                  <p><strong>风速:</strong> {{ weatherData.current.wind }}</p>
                </div>
              </div>
            </div>
            
            <div class="weather-forecast">
              <h4>未来三天预报</h4>
              <div class="forecast-list">
                <div v-for="day in weatherData.forecast" :key="day.day" class="forecast-item">
                  <div class="forecast-day">{{ day.day }}</div>
                  <div class="forecast-temp">{{ day.high }} / {{ day.low }}</div>
                  <div class="forecast-condition">{{ day.condition }}</div>
                </div>
              </div>
            </div>
            
            <div class="weather-recommendations">
              <h4>出行建议</h4>
              <ul>
                <li v-for="rec in weatherData.recommendations" :key="rec">{{ rec }}</li>
              </ul>
            </div>
          </div>
        </div>
      </div>

      <!-- 旅行推荐标签页 -->
      <div v-if="activeTab === 'recommendations'" class="tab-content">
        <div class="recommendations-container">
          <h2>个性化旅行推荐</h2>
          <div class="recommendations-form">
            <div class="form-group">
              <label>兴趣偏好</label>
              <textarea v-model="interests" rows="3" placeholder="描述你的兴趣，如：文化历史、美食、自然风光等"></textarea>
            </div>
            <div class="form-group">
              <label>预算水平</label>
              <select v-model="budget">
                <option>经济</option>
                <option>中等</option>
                <option>豪华</option>
              </select>
            </div>
            <div class="form-group">
              <label>旅行天数</label>
              <input type="number" v-model="duration" min="1" max="30">
            </div>
            <button @click="getRecommendations">获取推荐</button>
          </div>

          <div v-if="recommendations.length > 0" class="recommendations-list">
            <h3>推荐目的地</h3>
            <div class="recommendation-grid">
              <div v-for="rec in recommendations" :key="rec.name" class="recommendation-card" @click="selectDestination(rec)">
                <h4>{{ rec.name }}</h4>
                <p class="reason">{{ rec.reason }}</p>
                <div class="highlights">
                  <h5>亮点景点：</h5>
                  <div class="highlight-tags">
                    <span v-for="highlight in rec.highlights" :key="highlight" class="highlight-tag">
                      {{ highlight }}
                    </span>
                  </div>
                </div>
                <div class="destination-info">
                  <p><strong>最佳时间：</strong>{{ rec.best_time }}</p>
                </div>
                <span class="budget-level">{{ rec.budget_level }}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </main>
    
    <footer>
      <p>本科生工程实践项目 - AI赋能的WEB应用开发</p>
    </footer>
  </div>
</template>

<style scoped>
/* 现有样式保持不变 */
#app-container {
  max-width: 1200px;
  margin: 0 auto;
  padding: 20px;
  font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
}

header {
  text-align: center;
  margin-bottom: 30px;
}

header h1 {
  color: #2c3e50;
  margin-bottom: 10px;
  font-size: 2.5rem;
}

.subtitle {
  color: #7f8c8d;
  font-size: 1.1rem;
}

/* 新增标签导航样式 */
.tab-navigation {
  display: flex;
  justify-content: center;
  margin-bottom: 30px;
  gap: 10px;
  flex-wrap: wrap;
}

.tab-navigation button {
  padding: 12px 20px;
  border: none;
  background: #ffffff;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  cursor: pointer;
  font-size: 14px;
  transition: all 0.3s ease;
  color: #2c3e50;
  font-weight: 500;
}

.tab-navigation button.active {
  background: #007bff;
  color: white;
  border-color: #007bff;
}

.tab-navigation button:hover {
  background: #0056b3;
  color: white;
  border-color: #0056b3;
}

.tab-content {
  animation: fadeIn 0.3s ease-in-out;
}

/* 表单卡片样式 */
.form-card {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
  margin-bottom: 2rem;
}

.grid-container {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.form-group {
  display: flex;
  flex-direction: column;
}

.form-group.full-width {
  grid-column: 1 / -1;
}

.form-group label {
  margin-bottom: 0.5rem;
  font-weight: 600;
  color: #1a1a1a;
  font-size: 14px;
}

.form-group input,
.form-group select,
.form-group textarea {
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  transition: border-color 0.3s ease;
  color: #2c3e50;
  background: #ffffff;
}

.form-group input:focus,
.form-group select:focus,
.form-group textarea:focus {
  outline: none;
  border-color: #007bff;
  box-shadow: 0 0 0 3px rgba(0, 123, 255, 0.1);
}

.form-group input::placeholder,
.form-group textarea::placeholder {
  color: #6c757d;
  opacity: 0.7;
}

button {
  background: linear-gradient(135deg, #007bff, #0056b3);
  color: white;
  border: none;
  padding: 15px 30px;
  border-radius: 8px;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  width: 100%;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

button:hover:not(:disabled) {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(0, 123, 255, 0.3);
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

/* 结果容器样式 */
.result-container {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.loading-spinner {
  text-align: center;
  padding: 3rem;
}

.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #007bff;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 1s linear infinite;
  margin: 0 auto 1rem;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.error-message {
  background: #f8d7da;
  color: #721c24;
  padding: 1rem;
  border-radius: 8px;
  border: 1px solid #f5c6cb;
}

.placeholder {
  text-align: center;
  color: #495057;
  padding: 3rem;
  font-size: 1.2rem;
  font-weight: 500;
}

/* 计划操作按钮 */
.plan-actions {
  margin-bottom: 1rem;
  text-align: right;
}

.export-btn {
  background: #28a745;
  width: auto;
  padding: 10px 20px;
  font-size: 14px;
  color: white;
}

.export-btn:hover {
  background: #218838;
}

/* 历史记录样式 */
.history-container {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.history-container h2 {
  margin-bottom: 2rem;
  color: #1a1a1a;
  font-weight: 600;
}

.empty-history {
  text-align: center;
  color: #495057;
  padding: 3rem;
  font-weight: 500;
}

.history-list {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.history-item {
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  padding: 1.5rem;
  transition: all 0.3s ease;
  background: #ffffff;
}

.history-item:hover {
  box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
}

.history-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 1rem;
}

.history-header h3 {
  margin: 0;
  color: #1a1a1a;
  font-weight: 600;
}

.delete-btn {
  background: #dc3545;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
  width: auto;
  font-weight: 500;
}

.delete-btn:hover {
  background: #c82333;
}

.view-btn {
  background: #007bff;
  color: white;
  border: none;
  padding: 8px 12px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 12px;
  width: auto;
  font-weight: 500;
  margin-right: 8px;
}

.view-btn:hover {
  background: #0056b3;
}

.history-details {
  margin-bottom: 1rem;
  font-size: 14px;
  color: #495057;
}

.history-details p {
  margin: 0.25rem 0;
}

.history-details strong {
  color: #1a1a1a;
  font-weight: 600;
}

.history-preview {
  border-top: 1px solid #e0e0e0;
  padding-top: 1rem;
}

/* 预算计算器样式 */
.budget-calculator {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.budget-calculator h2 {
  margin-bottom: 2rem;
  color: #1a1a1a;
  font-weight: 600;
}

.budget-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.budget-results {
  border-top: 2px solid #e0e0e0;
  padding-top: 2rem;
}

.budget-results h3 {
  color: #1a1a1a;
  font-weight: 600;
  margin-bottom: 1.5rem;
}

.budget-summary {
  margin-bottom: 2rem;
}

.total-budget {
  text-align: center;
  margin-bottom: 2rem;
}

.total-budget h4 {
  font-size: 2rem;
  color: #28a745;
  margin-bottom: 0.5rem;
  font-weight: 700;
}

.total-budget p {
  color: #495057;
  font-weight: 500;
}

.budget-chart {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.budget-item {
  display: grid;
  grid-template-columns: 100px 1fr 100px;
  align-items: center;
  gap: 1rem;
}

.budget-label {
  font-weight: 600;
  color: #1a1a1a;
}

.budget-bar {
  height: 20px;
  background: #f8f9fa;
  border-radius: 10px;
  overflow: hidden;
  border: 1px solid #e0e0e0;
}

.budget-fill {
  height: 100%;
  background: linear-gradient(90deg, #007bff, #0056b3);
  transition: width 0.3s ease;
}

.budget-amount {
  text-align: right;
  font-weight: 600;
  color: #28a745;
}

.budget-recommendations {
  background: #f8f9fa;
  padding: 1.5rem;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
}

.budget-recommendations h4 {
  margin-bottom: 1rem;
  color: #1a1a1a;
  font-weight: 600;
}

.budget-recommendations ul {
  margin: 0;
  padding-left: 1.5rem;
}

.budget-recommendations li {
  margin-bottom: 0.5rem;
  color: #495057;
  line-height: 1.5;
}

/* 天气信息样式 */
.weather-container {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.weather-container h2 {
  margin-bottom: 2rem;
  color: #1a1a1a;
  font-weight: 600;
}

.weather-form {
  display: flex;
  gap: 1rem;
  margin-bottom: 2rem;
}

.weather-form input {
  flex: 1;
  padding: 12px;
  border: 2px solid #e0e0e0;
  border-radius: 8px;
  font-size: 16px;
  color: #2c3e50;
}

.weather-form button {
  width: auto;
  padding: 12px 24px;
  color: white;
}

.weather-info {
  border-top: 2px solid #e0e0e0;
  padding-top: 2rem;
}

.weather-info h3 {
  margin-bottom: 2rem;
  color: #1a1a1a;
  font-weight: 600;
}

.current-weather {
  background: linear-gradient(135deg, #74b9ff, #0984e3);
  color: white;
  padding: 2rem;
  border-radius: 12px;
  margin-bottom: 2rem;
}

.weather-main h4 {
  margin-bottom: 1rem;
  font-size: 1.5rem;
  font-weight: 600;
}

.weather-details p {
  margin: 0.5rem 0;
  font-size: 1.1rem;
  font-weight: 500;
}

.weather-forecast {
  margin-bottom: 2rem;
}

.weather-forecast h4 {
  margin-bottom: 1rem;
  color: #1a1a1a;
  font-weight: 600;
}

.forecast-list {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1rem;
}

.forecast-item {
  background: #f8f9fa;
  padding: 1.5rem;
  border-radius: 8px;
  text-align: center;
  border: 1px solid #e0e0e0;
}

.forecast-day {
  font-weight: 600;
  color: #1a1a1a;
  margin-bottom: 0.5rem;
}

.forecast-temp {
  font-size: 1.2rem;
  color: #007bff;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.forecast-condition {
  color: #495057;
  font-weight: 500;
}

.weather-recommendations {
  background: #fff3cd;
  padding: 1.5rem;
  border-radius: 8px;
  border: 1px solid #ffeaa7;
}

.weather-recommendations h4 {
  margin-bottom: 1rem;
  color: #856404;
  font-weight: 600;
}

.weather-recommendations ul {
  margin: 0;
  padding-left: 1.5rem;
}

.weather-recommendations li {
  margin-bottom: 0.5rem;
  color: #856404;
  line-height: 1.5;
}

/* 旅行推荐样式 */
.recommendations-container {
  background: white;
  border-radius: 12px;
  padding: 2rem;
  box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
}

.recommendations-container h2 {
  margin-bottom: 2rem;
  color: #1a1a1a;
  font-weight: 600;
}

.recommendations-form {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.recommendations-list {
  border-top: 2px solid #e0e0e0;
  padding-top: 2rem;
}

.recommendations-list h3 {
  margin-bottom: 2rem;
  color: #1a1a1a;
  font-weight: 600;
}

.recommendation-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
  gap: 1.5rem;
}

.recommendation-card {
  border: 2px solid #e0e0e0;
  border-radius: 12px;
  padding: 1.5rem;
  cursor: pointer;
  transition: all 0.3s ease;
  position: relative;
  background: #ffffff;
}

.recommendation-card:hover {
  border-color: #007bff;
  transform: translateY(-4px);
  box-shadow: 0 8px 25px rgba(0, 123, 255, 0.2);
}

.recommendation-card h4 {
  margin-bottom: 1rem;
  color: #1a1a1a;
  font-size: 1.3rem;
  font-weight: 600;
}

.reason {
  color: #495057;
  margin-bottom: 1rem;
  line-height: 1.6;
}

.highlights {
  margin-bottom: 1rem;
}

.highlights h5 {
  font-size: 1rem;
  color: #343a40;
  margin-bottom: 0.5rem;
  font-weight: 600;
}

.highlight-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 8px;
}

.highlight-tag {
  background: #e0e0e0;
  color: #343a40;
  padding: 4px 8px;
  border-radius: 6px;
  font-size: 0.9rem;
  font-weight: 500;
}

.destination-info {
  margin-top: 1rem;
  font-size: 0.9rem;
  color: #495057;
}

.budget-level {
  position: absolute;
  top: 1rem;
  right: 1rem;
  background: #007bff;
  color: white;
  padding: 4px 8px;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 600;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .tab-navigation {
    flex-direction: column;
  }
  
  .grid-container {
    grid-template-columns: 1fr;
  }
  
  .budget-form,
  .recommendations-form {
    grid-template-columns: 1fr;
  }
  
  .weather-form {
    flex-direction: column;
  }
  
  .forecast-list {
    grid-template-columns: 1fr;
  }
  
  .recommendation-grid {
    grid-template-columns: 1fr;
  }
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

footer {
  text-align: center;
  margin-top: 3rem;
  padding: 2rem;
  color: #495057;
  border-top: 1px solid #e0e0e0;
  font-weight: 500;
}

/* 模态框样式 */
.plan-detail-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal-overlay {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
}

.modal-content {
  position: relative;
  background: white;
  border-radius: 12px;
  width: 90%;
  max-width: 800px;
  max-height: 90vh;
  overflow: hidden;
  box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
  display: flex;
  flex-direction: column;
}

.modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 2rem;
  border-bottom: 1px solid #e0e0e0;
  background: #f8f9fa;
}

.modal-header h2 {
  margin: 0;
  color: #1a1a1a;
  font-weight: 600;
  font-size: 1.3rem;
}

.close-btn {
  background: none;
  border: none;
  font-size: 1.5rem;
  cursor: pointer;
  color: #6c757d;
  padding: 0;
  width: auto;
  font-weight: normal;
}

.close-btn:hover {
  color: #343a40;
}

.modal-body {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
}

.plan-info {
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 8px;
  margin-bottom: 1.5rem;
  border: 1px solid #e0e0e0;
}

.plan-info p {
  margin: 0.5rem 0;
  color: #495057;
  font-size: 14px;
}

.plan-info strong {
  color: #1a1a1a;
  font-weight: 600;
}

.plan-content {
  margin-top: 1rem;
}

.modal-footer {
  display: flex;
  justify-content: flex-end;
  gap: 1rem;
  padding: 1.5rem 2rem;
  border-top: 1px solid #e0e0e0;
  background: #f8f9fa;
}

.close-modal-btn {
  background: #6c757d;
  color: white;
  border: none;
  padding: 10px 20px;
  border-radius: 6px;
  cursor: pointer;
  font-size: 14px;
  width: auto;
  font-weight: 500;
}

.close-modal-btn:hover {
  background: #5a6268;
}

/* 响应式模态框 */
@media (max-width: 768px) {
  .modal-content {
    width: 95%;
    max-height: 95vh;
  }
  
  .modal-header,
  .modal-body,
  .modal-footer {
    padding: 1rem;
  }
  
  .modal-header h2 {
    font-size: 1.1rem;
  }
}
</style>