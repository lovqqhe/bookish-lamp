1. cd backend

pip install -r requirements.txt

flash run

2. cd frontend
npm i
npm run dev