import { defineStore } from 'pinia'
import { ref, computed } from 'vue'

export const useUserStore = defineStore('user', () => {
  const user = ref(null)
  const isAuthenticated = computed(() => !!user.value)

  async function login(credentials) {
    try {
      const response = await fetch('http://localhost:5000/api/login', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        credentials: 'include',
        body: JSON.stringify(credentials),
      })

      if (!response.ok) {
        let errorMessage = '登录失败'
        try {
          const errorData = await response.json()
          errorMessage = errorData.error || errorMessage
        } catch (parseError) {
          // 如果响应不是JSON格式，尝试获取文本内容
          const textError = await response.text()
          console.error('API响应不是JSON格式:', textError)
          errorMessage = '服务器响应格式错误'
        }
        throw new Error(errorMessage)
      }

      const data = await response.json()
      user.value = data.user
      return data
    } catch (error) {
      console.error('登录错误:', error)
      throw error
    }
  }

  async function register(userData) {
    try {
      const response = await fetch('http://localhost:5000/api/register', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(userData),
      })

      if (!response.ok) {
        let errorMessage = '注册失败'
        try {
          const errorData = await response.json()
          errorMessage = errorData.error || errorMessage
        } catch (parseError) {
          // 如果响应不是JSON格式，尝试获取文本内容
          const textError = await response.text()
          console.error('API响应不是JSON格式:', textError)
          errorMessage = '服务器响应格式错误'
        }
        throw new Error(errorMessage)
      }

      return await response.json()
    } catch (error) {
      console.error('注册错误:', error)
      throw error
    }
  }

  async function logout() {
    try {
      await fetch('http://localhost:5000/api/logout', {
        method: 'POST',
        credentials: 'include',
      })
      user.value = null
    } catch (error) {
      console.error('登出失败:', error)
    }
  }

  async function checkAuth() {
    try {
      const response = await fetch('http://localhost:5000/api/user/profile', {
        credentials: 'include',
      })
      
      if (response.ok) {
        const userData = await response.json()
        user.value = userData
        return true
      } else {
        user.value = null
        return false
      }
    } catch (error) {
      user.value = null
      return false
    }
  }

  return {
    user,
    isAuthenticated,
    login,
    register,
    logout,
    checkAuth
  }
})
