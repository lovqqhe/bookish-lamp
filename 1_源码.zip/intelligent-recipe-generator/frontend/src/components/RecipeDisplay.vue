<script setup>
import { ref, onMounted } from 'vue'
import { marked } from 'marked'

const props = defineProps({
  recipeMarkdown: {
    type: String,
    required: true
  }
})

const recipeHtml = ref('')

onMounted(() => {
  // 配置marked选项
  marked.setOptions({
    breaks: true,
    gfm: true
  })
  
  // 转换Markdown为HTML
  recipeHtml.value = marked(props.recipeMarkdown)
})
</script>

<template>
  <div class="recipe-display card">
    <div class="recipe-header">
      <div class="header-icon">📖</div>
      <h3 class="recipe-title">AI生成的食谱</h3>
    </div>
    
    <div class="recipe-content" v-html="recipeHtml"></div>
  </div>
</template>

<style scoped>
.recipe-display {
  position: relative;
  overflow: hidden;
}

.recipe-display::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #ff6b6b, #feca57, #48dbfb, #ff9ff3);
  border-radius: 2px;
}

.recipe-header {
  display: flex;
  align-items: center;
  gap: 1rem;
  margin-bottom: 2rem;
  padding-bottom: 1rem;
  border-bottom: 2px solid #f8f9fa;
}

.header-icon {
  font-size: 2rem;
  animation: bounce 2s infinite;
}

.recipe-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: #2c3e50;
  margin: 0;
}

.recipe-content {
  line-height: 1.8;
  color: #2c3e50;
}

/* Markdown样式优化 */
.recipe-content :deep(h1) {
  font-size: 1.8rem;
  font-weight: 700;
  color: #2c3e50;
  margin: 2rem 0 1rem 0;
  padding-bottom: 0.5rem;
  border-bottom: 2px solid #e9ecef;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.recipe-content :deep(h1)::before {
  content: '🍽️';
  font-size: 1.5rem;
}

.recipe-content :deep(h2) {
  font-size: 1.4rem;
  font-weight: 600;
  color: #495057;
  margin: 1.5rem 0 1rem 0;
  padding: 0.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.recipe-content :deep(h2)::before {
  content: '📋';
  font-size: 1.2rem;
}

.recipe-content :deep(h3) {
  font-size: 1.2rem;
  font-weight: 600;
  color: #6c757d;
  margin: 1rem 0 0.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.recipe-content :deep(h3)::before {
  content: '✨';
  font-size: 1rem;
}

.recipe-content :deep(p) {
  margin: 0.75rem 0;
  line-height: 1.7;
}

.recipe-content :deep(ul), 
.recipe-content :deep(ol) {
  margin: 1rem 0;
  padding-left: 1.5rem;
}

.recipe-content :deep(li) {
  margin: 0.5rem 0;
  line-height: 1.6;
  position: relative;
}

.recipe-content :deep(ul li)::marker {
  color: #667eea;
  font-weight: bold;
}

.recipe-content :deep(ol li)::marker {
  color: #667eea;
  font-weight: bold;
}

.recipe-content :deep(strong) {
  color: #2c3e50;
  font-weight: 600;
}

.recipe-content :deep(em) {
  color: #6c757d;
  font-style: italic;
}

.recipe-content :deep(code) {
  background: #f8f9fa;
  color: #e83e8c;
  padding: 0.2rem 0.4rem;
  border-radius: 4px;
  font-family: 'Courier New', monospace;
  font-size: 0.9em;
}

.recipe-content :deep(pre) {
  background: #f8f9fa;
  padding: 1rem;
  border-radius: 8px;
  overflow-x: auto;
  margin: 1rem 0;
  border-left: 4px solid #667eea;
}

.recipe-content :deep(blockquote) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 1rem 1.5rem;
  border-radius: 8px;
  margin: 1rem 0;
  border-left: 4px solid #ff6b6b;
  position: relative;
}

.recipe-content :deep(blockquote)::before {
  content: '💡';
  position: absolute;
  top: -0.5rem;
  left: 1rem;
  background: white;
  border-radius: 50%;
  width: 2rem;
  height: 2rem;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 1rem;
}

.recipe-content :deep(table) {
  width: 100%;
  border-collapse: collapse;
  margin: 1rem 0;
  background: white;
  border-radius: 8px;
  overflow: hidden;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
}

.recipe-content :deep(th) {
  background: #667eea;
  color: white;
  padding: 0.75rem;
  text-align: left;
  font-weight: 600;
}

.recipe-content :deep(td) {
  padding: 0.75rem;
  border-bottom: 1px solid #e9ecef;
}

.recipe-content :deep(tr:hover) {
  background: #f8f9fa;
}

/* 特殊样式 */
.recipe-content :deep(.ingredients) {
  background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
  padding: 1.5rem;
  border-radius: 12px;
  margin: 1rem 0;
  border-left: 4px solid #ff6b6b;
}

.recipe-content :deep(.instructions) {
  background: linear-gradient(135deg, #ffecd2 0%, #fcb69f 100%);
  padding: 1.5rem;
  border-radius: 12px;
  margin: 1rem 0;
  border-left: 4px solid #667eea;
}

.recipe-content :deep(.tips) {
  background: linear-gradient(135deg, #a8edea 0%, #fed6e3 100%);
  padding: 1.5rem;
  border-radius: 12px;
  margin: 1rem 0;
  border-left: 4px solid #feca57;
  position: relative;
}

.recipe-content :deep(.tips)::before {
  content: '💡 小贴士';
  position: absolute;
  top: -0.75rem;
  left: 1rem;
  background: #feca57;
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
}

/* 动画效果 */
@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-10px);
  }
  60% {
    transform: translateY(-5px);
  }
}

.recipe-display {
  animation: fadeInUp 0.6s ease-out;
}

.recipe-header {
  animation: slideInLeft 0.8s ease-out 0.2s both;
}

.recipe-content {
  animation: slideInUp 1s ease-out 0.4s both;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .recipe-header {
    flex-direction: column;
    text-align: center;
    gap: 0.5rem;
  }
  
  .header-icon {
    font-size: 1.5rem;
  }
  
  .recipe-title {
    font-size: 1.3rem;
  }
  
  .recipe-content :deep(h1) {
    font-size: 1.5rem;
  }
  
  .recipe-content :deep(h2) {
    font-size: 1.2rem;
  }
  
  .recipe-content :deep(h3) {
    font-size: 1.1rem;
  }
  
  .recipe-content :deep(blockquote) {
    padding: 1rem;
  }
  
  .recipe-content :deep(.ingredients),
  .recipe-content :deep(.instructions),
  .recipe-content :deep(.tips) {
    padding: 1rem;
  }
}

/* 深色模式适配 */
@media (prefers-color-scheme: dark) {
  .recipe-title {
    color: #e1e8ed;
  }
  
  .recipe-content {
    color: #e1e8ed;
  }
  
  .recipe-content :deep(h1) {
    color: #e1e8ed;
    border-bottom-color: #404040;
  }
  
  .recipe-content :deep(h2) {
    color: #c0c0c0;
  }
  
  .recipe-content :deep(h3) {
    color: #a0a0a0;
  }
  
  .recipe-content :deep(code) {
    background: #404040;
    color: #ff6b6b;
  }
  
  .recipe-content :deep(pre) {
    background: #404040;
  }
  
  .recipe-content :deep(td) {
    border-bottom-color: #404040;
  }
  
  .recipe-content :deep(tr:hover) {
    background: #404040;
  }
  
  .recipe-header {
    border-bottom-color: #404040;
  }
}

/* 悬停效果 */
.recipe-display:hover {
  transform: translateY(-2px);
  transition: transform 0.3s ease;
}

/* 打印样式 */
@media print {
  .recipe-display {
    box-shadow: none;
    border: 1px solid #ddd;
  }
  
  .recipe-header {
    border-bottom: 1px solid #ddd;
  }
  
  .recipe-content :deep(blockquote) {
    background: #f8f9fa;
    color: #2c3e50;
  }
}
</style>