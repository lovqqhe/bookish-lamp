<script setup>
import { computed } from 'vue';
import { marked } from 'marked';

const props = defineProps({
  planMarkdown: {
    type: String,
    required: true,
  },
});

const renderedHtml = computed(() => {
  if (props.planMarkdown) {
    marked.setOptions({
      gfm: true,
      breaks: true,
      sanitize: true,
    });
    return marked.parse(props.planMarkdown);
  }
  return '';
});
</script>

<template>
  <div class="plan-card" v-html="renderedHtml"></div>
</template>

<style scoped>
.plan-card {
  background-color: #ffffff;
  border-radius: 12px;
  padding: 1.5rem 2.5rem;
  box-shadow: 0 8px 30px rgba(0, 0, 0, 0.08);
  animation: fadeIn 0.5s ease-in-out;
  line-height: 1.8;
  border-left: 5px solid #007bff;
  color: #1a1a1a;
}

:deep(h1) {
  font-size: 2.2rem;
  color: #1a1a1a;
  margin-bottom: 1.5rem;
  text-align: center;
  font-weight: 700;
}

:deep(h2) {
  font-size: 1.6rem;
  color: #0056b3;
  margin-top: 2.5rem;
  margin-bottom: 1rem;
  border-bottom: 2px solid #e0e0e0;
  padding-bottom: 0.5rem;
  font-weight: 600;
}

:deep(h3) {
  font-size: 1.3rem;
  color: #1a1a1a;
  margin-top: 2rem;
  margin-bottom: 1rem;
  font-weight: 600;
}

:deep(ul), :deep(ol) {
  padding-left: 1.5rem;
}

:deep(li) {
  margin-bottom: 0.75rem;
  color: #2c3e50;
  line-height: 1.6;
}

:deep(strong) {
  color: #007bff;
  font-weight: 600;
}

:deep(em) {
    font-style: italic;
    color: #495057;
}

:deep(p) {
  color: #2c3e50;
  line-height: 1.6;
  margin-bottom: 1rem;
}

@keyframes fadeIn {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
