<script setup>
import { ref, onMounted, computed } from 'vue';
import { useUserStore } from './stores/user';
import RecipeDisplay from './components/RecipeDisplay.vue';
import NutritionLabel from './components/NutritionLabel.vue';
import UserAuth from './components/UserAuth.vue';
import RecipeSearch from './components/RecipeSearch.vue';

const userStore = useUserStore();

// 表单数据
const ingredients = ref('鸡胸肉, 西红柿, 鸡蛋, 青椒');
const preferences = ref('少油少盐, 微辣');
const mealType = ref('工作日晚餐');

// 状态管理
const generatedRecipe = ref('');
const recipeInfo = ref({});
const nutritionInfo = ref({});
const isLoading = ref(false);
const error = ref(null);
const currentView = ref('generator'); // generator, search, favorites, history
const searchResults = ref([]);
const favorites = ref([]);
const history = ref([]);

// 计算属性
const isAuthenticated = computed(() => userStore.isAuthenticated);

onMounted(async () => {
  await userStore.checkAuth();
  if (isAuthenticated.value) {
    await loadFavorites();
    await loadHistory();
  }
});

// 调用后端API生成食谱
async function generateRecipe() {
  isLoading.value = true;
  error.value = null;
  generatedRecipe.value = '';
  recipeInfo.value = {};
  nutritionInfo.value = {};

  try {
    const response = await fetch('http://localhost:5000/api/generate-recipe', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      credentials: 'include',
      body: JSON.stringify({
        ingredients: ingredients.value,
        preferences: preferences.value,
        mealType: mealType.value,
      }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    generatedRecipe.value = data.recipe;
    recipeInfo.value = data.recipe_info || {};
    nutritionInfo.value = data.nutrition || {};
    
    // 如果用户已登录，刷新收藏和历史
    if (isAuthenticated.value) {
      await loadFavorites();
      await loadHistory();
    }
  } catch (e) {
    console.error('Error generating recipe:', e);
    error.value = `生成失败: ${e.message}. 请检查后端服务是否运行，以及API密钥是否正确配置。`;
  } finally {
    isLoading.value = false;
  }
}

// 收藏相关功能
async function loadFavorites() {
  try {
    const response = await fetch('http://localhost:5000/api/favorites', {
      credentials: 'include',
    });
    if (response.ok) {
      favorites.value = await response.json();
    }
  } catch (error) {
    console.error('加载收藏失败:', error);
  }
}

async function addToFavorites(recipeId) {
  try {
    const response = await fetch(`http://localhost:5000/api/favorites/${recipeId}`, {
      method: 'POST',
      credentials: 'include',
    });
    if (response.ok) {
      await loadFavorites();
    }
  } catch (error) {
    console.error('添加收藏失败:', error);
  }
}

async function removeFromFavorites(recipeId) {
  try {
    const response = await fetch(`http://localhost:5000/api/favorites/${recipeId}`, {
      method: 'DELETE',
      credentials: 'include',
    });
    if (response.ok) {
      await loadFavorites();
    }
  } catch (error) {
    console.error('取消收藏失败:', error);
  }
}

// 历史记录相关功能
async function loadHistory() {
  try {
    const response = await fetch('http://localhost:5000/api/history', {
      credentials: 'include',
    });
    if (response.ok) {
      history.value = await response.json();
    }
  } catch (error) {
    console.error('加载历史失败:', error);
  }
}

// 搜索相关功能
function handleSearch(results) {
  searchResults.value = results;
  currentView.value = 'search';
}

// 视图切换
function switchView(view) {
  currentView.value = view;
}

// 用户登出
async function handleLogout() {
  await userStore.logout();
  favorites.value = [];
  history.value = [];
  currentView.value = 'generator';
}
</script>

<template>
  <div id="app-container">
    <!-- 导航栏 -->
    <nav class="navbar glass">
      <div class="nav-brand">
        <h1 class="brand-title">
          <span class="brand-icon">🍳</span>
          智能食谱生成器
        </h1>
      </div>
      
      <div class="nav-menu">
        <button 
          @click="switchView('generator')" 
          :class="{ active: currentView === 'generator' }"
          class="nav-button"
        >
          <span class="nav-icon">✨</span>
          生成食谱
        </button>
        
        <button 
          @click="switchView('search')" 
          :class="{ active: currentView === 'search' }"
          class="nav-button"
        >
          <span class="nav-icon">🔍</span>
          搜索食谱
        </button>
        
        <template v-if="isAuthenticated">
          <button 
            @click="switchView('favorites')" 
            :class="{ active: currentView === 'favorites' }"
            class="nav-button"
          >
            <span class="nav-icon">❤️</span>
            我的收藏
          </button>
          
          <button 
            @click="switchView('history')" 
            :class="{ active: currentView === 'history' }"
            class="nav-button"
          >
            <span class="nav-icon">📚</span>
            历史记录
          </button>
        </template>
      </div>
      
      <div class="nav-user">
        <template v-if="isAuthenticated">
          <span class="username">
            <span class="user-icon">👤</span>
            {{ userStore.user?.username }}
          </span>
          <button @click="handleLogout" class="btn btn-danger">
            <span class="btn-icon">🚪</span>
            登出
          </button>
        </template>
        <template v-else>
          <button @click="switchView('auth')" class="btn btn-success">
            <span class="btn-icon">🔑</span>
            登录
          </button>
        </template>
      </div>
    </nav>

    <!-- 主要内容区域 -->
    <main class="main-content">
      <!-- 用户认证页面 -->
      <UserAuth v-if="currentView === 'auth'" />
      
      <!-- 食谱生成页面 -->
      <div v-else-if="currentView === 'generator'" class="generator-page">
        <div class="form-card card slide-in-left">
          <div class="card-header">
            <h2 class="card-title">
              <span class="title-icon">🎯</span>
              告诉我你有什么？
            </h2>
            <p class="card-subtitle">输入你的食材，让AI为你创造美味食谱</p>
          </div>
          
          <div class="form-content">
            <div class="form-group">
              <label for="ingredients" class="label">食材（用逗号隔开）</label>
              <textarea 
                id="ingredients" 
                v-model="ingredients" 
                rows="3" 
                placeholder="例如: 牛肉, 土豆, 洋葱, 胡萝卜"
                class="input"
              ></textarea>
            </div>
            
            <div class="form-group">
              <label for="preferences" class="label">口味偏好 / 饮食要求</label>
              <input 
                type="text" 
                id="preferences" 
                v-model="preferences" 
                placeholder="例如: 素食, 低碳水, 喜欢酸甜口"
                class="input"
              >
            </div>
            
            <div class="form-group">
              <label for="meal-type" class="label">餐食类型</label>
              <input 
                type="text" 
                id="meal-type" 
                v-model="mealType" 
                placeholder="例如: 快捷早餐, 周末大餐, 健身餐"
                class="input"
              >
            </div>
            
            <button @click="generateRecipe" :disabled="isLoading" class="btn btn-primary generate-btn">
              <span v-if="isLoading" class="loading"></span>
              <span v-else class="btn-icon">✨</span>
              {{ isLoading ? '正在思考中...' : '生成创意食谱' }}
            </button>
          </div>
        </div>

        <div class="result-container card slide-in-right">
          <div v-if="isLoading" class="loading-container">
            <div class="loading-animation">
              <div class="chef-hat">👨‍🍳</div>
              <div class="cooking-pots">
                <span class="pot">🍳</span>
                <span class="pot">🥘</span>
                <span class="pot">🍲</span>
              </div>
            </div>
            <p class="loading-text">AI大厨正在为您创作...</p>
          </div>
          
          <div v-if="error" class="error-message">
            <div class="error-icon">⚠️</div>
            <p>{{ error }}</p>
          </div>
          
          <div v-if="generatedRecipe && !isLoading" class="recipe-result fade-in-up">
            <RecipeDisplay :recipeMarkdown="generatedRecipe" />
            <NutritionLabel v-if="nutritionInfo.nutrition_facts" :nutrition="nutritionInfo" />
          </div>
          
          <div v-if="!generatedRecipe && !isLoading && !error" class="placeholder">
            <div class="placeholder-icon">🍽️</div>
            <p>输入你的食材，让AI给你惊喜！</p>
          </div>
        </div>
      </div>

      <!-- 搜索页面 -->
      <div v-else-if="currentView === 'search'" class="search-page">
        <RecipeSearch @search="handleSearch" />
        
        <div v-if="searchResults.length > 0" class="search-results fade-in-up">
          <h3 class="results-title">
            <span class="title-icon">🔍</span>
            搜索结果 ({{ searchResults.length }})
          </h3>
          <div class="recipe-grid grid grid-3">
            <div 
              v-for="recipe in searchResults" 
              :key="recipe.id" 
              class="recipe-card card"
            >
              <div class="recipe-header">
                <h4 class="recipe-title">{{ recipe.title }}</h4>
                <div class="recipe-meta">
                  <span class="badge">{{ recipe.cuisine_type }}</span>
                  <span class="badge badge-secondary">{{ recipe.difficulty }}</span>
                  <span class="badge badge-success">{{ recipe.meal_type }}</span>
                  <span class="cooking-time">
                    <span class="time-icon">⏱️</span>
                    {{ recipe.cooking_time }}分钟
                  </span>
                </div>
              </div>
              <div class="recipe-actions">
                <button @click="addToFavorites(recipe.id)" class="btn btn-success">
                  <span class="btn-icon">❤️</span>
                  收藏
                </button>
              </div>
            </div>
          </div>
        </div>
        
        <div v-else-if="searchResults.length === 0 && currentView === 'search'" class="no-results">
          <div class="no-results-icon">🔍</div>
          <p>没有找到相关食谱</p>
        </div>
      </div>

      <!-- 收藏页面 -->
      <div v-else-if="currentView === 'favorites'" class="favorites-page">
        <div class="page-header">
          <h2 class="page-title">
            <span class="title-icon">❤️</span>
            我的收藏
          </h2>
        </div>
        
        <div v-if="favorites.length > 0" class="recipe-grid grid grid-3">
          <div 
            v-for="recipe in favorites" 
            :key="recipe.id" 
            class="recipe-card card"
          >
            <div class="recipe-header">
              <h4 class="recipe-title">{{ recipe.title }}</h4>
              <div class="recipe-meta">
                <span class="badge">{{ recipe.cuisine_type }}</span>
                <span class="badge badge-secondary">{{ recipe.difficulty }}</span>
                <span class="cooking-time">
                  <span class="time-icon">⏱️</span>
                  {{ recipe.cooking_time }}分钟
                </span>
              </div>
            </div>
            <div class="recipe-actions">
              <button @click="removeFromFavorites(recipe.id)" class="btn btn-danger">
                <span class="btn-icon">🗑️</span>
                取消收藏
              </button>
            </div>
          </div>
        </div>
        
        <div v-else class="no-favorites">
          <div class="no-favorites-icon">💔</div>
          <p>还没有收藏任何食谱</p>
        </div>
      </div>

      <!-- 历史记录页面 -->
      <div v-else-if="currentView === 'history'" class="history-page">
        <div class="page-header">
          <h2 class="page-title">
            <span class="title-icon">📚</span>
            历史记录
          </h2>
        </div>
        
        <div v-if="history.length > 0" class="history-list">
          <div 
            v-for="record in history" 
            :key="record.id" 
            class="history-item card"
          >
            <div class="history-content">
              <h4 class="history-title">{{ record.title }}</h4>
              <div class="history-meta">
                <span class="meta-item">
                  <span class="meta-icon">🥬</span>
                  食材: {{ record.ingredients_input }}
                </span>
                <span class="meta-item">
                  <span class="meta-icon">🎯</span>
                  偏好: {{ record.preferences }}
                </span>
                <span class="meta-item">
                  <span class="meta-icon">🍽️</span>
                  类型: {{ record.meal_type }}
                </span>
              </div>
              <p class="history-date">
                <span class="date-icon">📅</span>
                {{ new Date(record.created_at).toLocaleString() }}
              </p>
            </div>
          </div>
        </div>
        
        <div v-else class="no-history">
          <div class="no-history-icon">📝</div>
          <p>还没有生成过食谱</p>
        </div>
      </div>
    </main>

    <footer class="footer glass">
      <p>本科生工程实践项目 - AI赋能的WEB应用开发</p>
    </footer>
  </div>
</template>

<style scoped>
/* 应用容器 */
#app-container {
  min-height: 100vh;
  display: flex;
  flex-direction: column;
}

/* 导航栏样式 */
.navbar {
  padding: 1rem 2rem;
  display: flex;
  justify-content: space-between;
  align-items: center;
  position: sticky;
  top: 0;
  z-index: 1000;
  margin-bottom: 2rem;
}

.nav-brand .brand-title {
  margin: 0;
  font-size: 1.8rem;
  font-weight: 700;
  color: white;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.brand-icon {
  font-size: 2rem;
  animation: pulse 2s infinite;
}

.nav-menu {
  display: flex;
  gap: 1rem;
  flex-wrap: wrap;
}

.nav-button {
  background: rgba(255, 255, 255, 0.1);
  color: white;
  border: none;
  padding: 0.75rem 1.5rem;
  cursor: pointer;
  border-radius: 12px;
  transition: all 0.3s ease;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 500;
  backdrop-filter: blur(10px);
}

.nav-button:hover,
.nav-button.active {
  background: rgba(255, 255, 255, 0.2);
  transform: translateY(-2px);
}

.nav-icon {
  font-size: 1.2rem;
}

.nav-user {
  display: flex;
  align-items: center;
  gap: 1rem;
}

.username {
  font-weight: 500;
  color: white;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.user-icon {
  font-size: 1.2rem;
}

/* 主要内容区域 */
.main-content {
  flex: 1;
  padding: 0 2rem 2rem;
  max-width: 1400px;
  margin: 0 auto;
  width: 100%;
}

/* 生成器页面 */
.generator-page {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 2rem;
  align-items: start;
}

.card-header {
  margin-bottom: 2rem;
}

.card-title {
  font-size: 1.8rem;
  color: #2c3e50;
  margin-bottom: 0.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.title-icon {
  font-size: 1.5rem;
}

.card-subtitle {
  color: #6c757d;
  font-size: 1rem;
}

.form-content {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

/* 生成按钮 */
.generate-btn {
  width: 100%;
  padding: 1rem;
  font-size: 1.1rem;
  margin-top: 1rem;
}

.btn-icon {
  margin-right: 0.5rem;
}

/* 结果容器 */
.result-container {
  min-height: 400px;
  display: flex;
  align-items: center;
  justify-content: center;
}

.loading-container {
  text-align: center;
  padding: 3rem;
}

.loading-animation {
  margin-bottom: 2rem;
}

.chef-hat {
  font-size: 4rem;
  animation: pulse 2s infinite;
  margin-bottom: 1rem;
}

.cooking-pots {
  display: flex;
  justify-content: center;
  gap: 1rem;
}

.pot {
  font-size: 2rem;
  animation: bounce 1s infinite;
}

.pot:nth-child(2) {
  animation-delay: 0.2s;
}

.pot:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes bounce {
  0%, 20%, 50%, 80%, 100% {
    transform: translateY(0);
  }
  40% {
    transform: translateY(-10px);
  }
  60% {
    transform: translateY(-5px);
  }
}

.loading-text {
  font-size: 1.2rem;
  color: #6c757d;
  font-weight: 500;
}

.error-message {
  background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
  color: white;
  padding: 2rem;
  border-radius: 16px;
  text-align: center;
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1rem;
}

.error-icon {
  font-size: 3rem;
}

.placeholder {
  text-align: center;
  color: #6c757d;
  padding: 3rem;
}

.placeholder-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
  opacity: 0.5;
}

/* 搜索页面 */
.search-page {
  max-width: 1200px;
  margin: 0 auto;
}

.results-title {
  margin-bottom: 2rem;
  color: #2c3e50;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.5rem;
}

/* 食谱卡片 */
.recipe-card {
  display: flex;
  flex-direction: column;
  justify-content: space-between;
  height: 100%;
}

.recipe-header {
  margin-bottom: 1rem;
}

.recipe-title {
  margin: 0 0 1rem 0;
  color: #2c3e50;
  font-size: 1.2rem;
  line-height: 1.4;
}

.recipe-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 0.5rem;
  margin-bottom: 1rem;
}

.cooking-time {
  background: linear-gradient(135deg, #4facfe 0%, #00f2fe 100%);
  color: white;
  padding: 0.25rem 0.75rem;
  border-radius: 20px;
  font-size: 0.8rem;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

.time-icon {
  font-size: 0.9rem;
}

.recipe-actions {
  margin-top: auto;
}

/* 页面头部 */
.page-header {
  margin-bottom: 2rem;
}

.page-title {
  font-size: 2rem;
  color: #2c3e50;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

/* 历史记录 */
.history-list {
  display: flex;
  flex-direction: column;
  gap: 1rem;
}

.history-item {
  transition: all 0.3s ease;
}

.history-item:hover {
  transform: translateX(5px);
}

.history-title {
  margin: 0 0 0.5rem 0;
  color: #2c3e50;
  font-size: 1.2rem;
}

.history-meta {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  margin: 1rem 0;
}

.meta-item {
  color: #6c757d;
  font-size: 0.9rem;
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

.meta-icon {
  font-size: 1rem;
}

.history-date {
  color: #adb5bd;
  font-size: 0.8rem;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 0.25rem;
}

.date-icon {
  font-size: 0.9rem;
}

/* 空状态 */
.no-results,
.no-favorites,
.no-history {
  text-align: center;
  color: #6c757d;
  padding: 4rem 2rem;
  background: rgba(255, 255, 255, 0.5);
  border-radius: 20px;
  backdrop-filter: blur(10px);
}

.no-results-icon,
.no-favorites-icon,
.no-history-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
  opacity: 0.5;
}

/* 页脚 */
.footer {
  text-align: center;
  padding: 1.5rem;
  color: white;
  margin-top: auto;
}

/* 响应式设计 */
@media (max-width: 1024px) {
  .generator-page {
    grid-template-columns: 1fr;
    gap: 1.5rem;
  }
}

@media (max-width: 768px) {
  .navbar {
    flex-direction: column;
    gap: 1rem;
    padding: 1rem;
  }
  
  .nav-menu {
    flex-wrap: wrap;
    justify-content: center;
  }
  
  .nav-user {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .main-content {
    padding: 0 1rem 1rem;
  }
  
  .recipe-meta {
    flex-direction: column;
    gap: 0.25rem;
  }
  
  .history-meta {
    flex-direction: column;
    gap: 0.5rem;
  }
  
  .card-title,
  .page-title {
    font-size: 1.5rem;
  }
}

/* 深色模式适配 */
@media (prefers-color-scheme: dark) {
  .card-title,
  .page-title,
  .recipe-title,
  .history-title {
    color: #e1e8ed;
  }
  
  .card-subtitle,
  .loading-text,
  .placeholder,
  .no-results,
  .no-favorites,
  .no-history {
    color: #a0a0a0;
  }
  
  .meta-item {
    color: #808080;
  }
  
  .history-date {
    color: #606060;
  }
}
</style>