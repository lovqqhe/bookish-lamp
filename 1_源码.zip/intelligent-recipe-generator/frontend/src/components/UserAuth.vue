<script setup>
import { ref } from 'vue'
import { useUserStore } from '../stores/user'

const userStore = useUserStore()

const isLogin = ref(true)
const loading = ref(false)
const error = ref('')

// 登录表单
const loginForm = ref({
  username: '',
  password: ''
})

// 注册表单
const registerForm = ref({
  username: '',
  email: '',
  password: '',
  confirmPassword: ''
})

async function handleLogin() {
  if (!loginForm.value.username || !loginForm.value.password) {
    error.value = '请填写所有字段'
    return
  }

  loading.value = true
  error.value = ''

  try {
    await userStore.login(loginForm.value)
    error.value = ''
  } catch (err) {
    error.value = err.message
  } finally {
    loading.value = false
  }
}

async function handleRegister() {
  if (!registerForm.value.username || !registerForm.value.email || 
      !registerForm.value.password || !registerForm.value.confirmPassword) {
    error.value = '请填写所有字段'
    return
  }

  if (registerForm.value.password !== registerForm.value.confirmPassword) {
    error.value = '两次输入的密码不一致'
    return
  }

  if (registerForm.value.password.length < 6) {
    error.value = '密码长度至少6位'
    return
  }

  loading.value = true
  error.value = ''

  try {
    await userStore.register({
      username: registerForm.value.username,
      email: registerForm.value.email,
      password: registerForm.value.password
    })
    // 注册成功后切换到登录
    isLogin.value = true
    error.value = '注册成功，请登录'
  } catch (err) {
    error.value = err.message
  } finally {
    loading.value = false
  }
}

function toggleMode() {
  isLogin.value = !isLogin.value
  error.value = ''
  loginForm.value = { username: '', password: '' }
  registerForm.value = { username: '', email: '', password: '', confirmPassword: '' }
}
</script>

<template>
  <div class="auth-container">
    <div class="auth-card card">
      <div class="auth-header">
        <div class="auth-icon">
          <span v-if="isLogin">🔑</span>
          <span v-else>📝</span>
        </div>
        <h2 class="auth-title">{{ isLogin ? '欢迎回来' : '创建账号' }}</h2>
        <p class="auth-subtitle">
          {{ isLogin ? '登录您的账户以继续使用' : '注册新账户开始您的烹饪之旅' }}
        </p>
      </div>
      
      <div v-if="error" class="error-message">
        <div class="error-icon">⚠️</div>
        <p>{{ error }}</p>
      </div>

      <!-- 登录表单 -->
      <form v-if="isLogin" @submit.prevent="handleLogin" class="auth-form">
        <div class="form-group">
          <label for="username" class="label">
            <span class="label-icon">👤</span>
            用户名
          </label>
          <input 
            type="text" 
            id="username" 
            v-model="loginForm.username" 
            placeholder="请输入您的用户名"
            class="input"
            required
          >
        </div>
        
        <div class="form-group">
          <label for="password" class="label">
            <span class="label-icon">🔒</span>
            密码
          </label>
          <input 
            type="password" 
            id="password" 
            v-model="loginForm.password" 
            placeholder="请输入您的密码"
            class="input"
            required
          >
        </div>
        
        <button type="submit" :disabled="loading" class="btn btn-primary auth-button">
          <span v-if="loading" class="loading"></span>
          <span v-else class="btn-icon">🚀</span>
          {{ loading ? '登录中...' : '登录' }}
        </button>
      </form>

      <!-- 注册表单 -->
      <form v-else @submit.prevent="handleRegister" class="auth-form">
        <div class="form-group">
          <label for="reg-username" class="label">
            <span class="label-icon">👤</span>
            用户名
          </label>
          <input 
            type="text" 
            id="reg-username" 
            v-model="registerForm.username" 
            placeholder="请输入用户名"
            class="input"
            required
          >
        </div>
        
        <div class="form-group">
          <label for="email" class="label">
            <span class="label-icon">📧</span>
            邮箱
          </label>
          <input 
            type="email" 
            id="email" 
            v-model="registerForm.email" 
            placeholder="请输入邮箱地址"
            class="input"
            required
          >
        </div>
        
        <div class="form-group">
          <label for="reg-password" class="label">
            <span class="label-icon">🔒</span>
            密码
          </label>
          <input 
            type="password" 
            id="reg-password" 
            v-model="registerForm.password" 
            placeholder="请输入密码（至少6位）"
            class="input"
            required
          >
        </div>
        
        <div class="form-group">
          <label for="confirm-password" class="label">
            <span class="label-icon">🔐</span>
            确认密码
          </label>
          <input 
            type="password" 
            id="confirm-password" 
            v-model="registerForm.confirmPassword" 
            placeholder="请再次输入密码"
            class="input"
            required
          >
        </div>
        
        <button type="submit" :disabled="loading" class="btn btn-success auth-button">
          <span v-if="loading" class="loading"></span>
          <span v-else class="btn-icon">✨</span>
          {{ loading ? '注册中...' : '注册' }}
        </button>
      </form>

      <div class="auth-footer">
        <div class="divider">
          <span class="divider-text">或者</span>
        </div>
        <p class="toggle-text">
          {{ isLogin ? '还没有账号？' : '已有账号？' }}
          <button @click="toggleMode" class="toggle-button">
            {{ isLogin ? '立即注册' : '立即登录' }}
          </button>
        </p>
      </div>
    </div>
  </div>
</template>

<style scoped>
.auth-container {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
  padding: 2rem;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  position: relative;
  overflow: hidden;
}

.auth-container::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="75" cy="75" r="1" fill="rgba(255,255,255,0.1)"/><circle cx="50" cy="10" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="10" cy="60" r="0.5" fill="rgba(255,255,255,0.1)"/><circle cx="90" cy="40" r="0.5" fill="rgba(255,255,255,0.1)"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
  opacity: 0.3;
}

.auth-card {
  width: 100%;
  max-width: 450px;
  position: relative;
  z-index: 1;
  animation: fadeInUp 0.8s ease-out;
}

.auth-header {
  text-align: center;
  margin-bottom: 2rem;
}

.auth-icon {
  font-size: 4rem;
  margin-bottom: 1rem;
  animation: pulse 2s infinite;
}

.auth-title {
  font-size: 2rem;
  font-weight: 700;
  color: #2c3e50;
  margin: 0 0 0.5rem 0;
}

.auth-subtitle {
  color: #6c757d;
  font-size: 1rem;
  margin: 0;
  line-height: 1.5;
}

.error-message {
  background: linear-gradient(135deg, #ff6b6b 0%, #ee5a24 100%);
  color: white;
  padding: 1rem;
  border-radius: 12px;
  margin-bottom: 1.5rem;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  animation: shake 0.5s ease-in-out;
}

@keyframes shake {
  0%, 100% { transform: translateX(0); }
  25% { transform: translateX(-5px); }
  75% { transform: translateX(5px); }
}

.error-icon {
  font-size: 1.2rem;
}

.auth-form {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
  margin-bottom: 2rem;
}

.form-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.label {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  color: #2c3e50;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.label-icon {
  font-size: 1rem;
}

.input {
  width: 100%;
  padding: 1rem 1.25rem;
  border: 2px solid #e1e8ed;
  border-radius: 12px;
  font-size: 1rem;
  transition: all 0.3s ease;
  background: rgba(255, 255, 255, 0.9);
  backdrop-filter: blur(10px);
}

.input:focus {
  outline: none;
  border-color: #667eea;
  box-shadow: 0 0 0 3px rgba(102, 126, 234, 0.1);
  transform: translateY(-1px);
}

.input::placeholder {
  color: #a0a0a0;
}

.auth-button {
  width: 100%;
  padding: 1rem;
  font-size: 1.1rem;
  font-weight: 600;
  margin-top: 0.5rem;
  position: relative;
  overflow: hidden;
}

.auth-button::before {
  content: '';
  position: absolute;
  top: 0;
  left: -100%;
  width: 100%;
  height: 100%;
  background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.2), transparent);
  transition: left 0.5s;
}

.auth-button:hover::before {
  left: 100%;
}

.auth-footer {
  text-align: center;
}

.divider {
  position: relative;
  margin: 1.5rem 0;
}

.divider::before {
  content: '';
  position: absolute;
  top: 50%;
  left: 0;
  right: 0;
  height: 1px;
  background: linear-gradient(90deg, transparent, #e1e8ed, transparent);
}

.divider-text {
  background: white;
  padding: 0 1rem;
  color: #6c757d;
  font-size: 0.9rem;
  position: relative;
  z-index: 1;
}

.toggle-text {
  margin: 0;
  color: #6c757d;
  font-size: 0.9rem;
}

.toggle-button {
  background: none;
  border: none;
  color: #667eea;
  cursor: pointer;
  font-weight: 600;
  text-decoration: underline;
  transition: color 0.3s ease;
  margin-left: 0.5rem;
}

.toggle-button:hover {
  color: #5a67d8;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .auth-container {
    padding: 1rem;
  }
  
  .auth-card {
    max-width: 100%;
  }
  
  .auth-title {
    font-size: 1.5rem;
  }
  
  .auth-icon {
    font-size: 3rem;
  }
  
  .input {
    padding: 0.875rem 1rem;
    font-size: 0.9rem;
  }
  
  .auth-button {
    padding: 0.875rem;
    font-size: 1rem;
  }
}

/* 深色模式适配 */
@media (prefers-color-scheme: dark) {
  .auth-title {
    color: #e1e8ed;
  }
  
  .auth-subtitle {
    color: #a0a0a0;
  }
  
  .label {
    color: #e1e8ed;
  }
  
  .input {
    background: rgba(30, 30, 30, 0.9);
    border-color: #404040;
    color: #e1e8ed;
  }
  
  .input::placeholder {
    color: #808080;
  }
  
  .toggle-text {
    color: #a0a0a0;
  }
  
  .divider::before {
    background: linear-gradient(90deg, transparent, #404040, transparent);
  }
  
  .divider-text {
    background: rgba(255, 255, 255, 0.95);
  }
}

/* 加载动画 */
.loading {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
  margin-right: 0.5rem;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* 按钮图标 */
.btn-icon {
  margin-right: 0.5rem;
  font-size: 1.1rem;
}
</style>
