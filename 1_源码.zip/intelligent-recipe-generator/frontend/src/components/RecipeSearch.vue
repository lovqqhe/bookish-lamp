<script setup>
import { ref, onMounted } from 'vue'

const emit = defineEmits(['search'])

const searchQuery = ref('')
const cuisineType = ref('')
const difficulty = ref('')
const mealType = ref('')
const categories = ref({
  cuisine_types: [],
  difficulties: [],
  meal_types: []
})

const loading = ref(false)

onMounted(async () => {
  await loadCategories()
})

async function loadCategories() {
  try {
    const response = await fetch('http://localhost:5000/api/categories')
    if (response.ok) {
      categories.value = await response.json()
    }
  } catch (error) {
    console.error('加载分类失败:', error)
  }
}

async function performSearch() {
  loading.value = true
  
  try {
    const params = new URLSearchParams()
    if (searchQuery.value) params.append('q', searchQuery.value)
    if (cuisineType.value) params.append('cuisine_type', cuisineType.value)
    if (difficulty.value) params.append('difficulty', difficulty.value)
    if (mealType.value) params.append('meal_type', mealType.value)
    
    const response = await fetch(`http://localhost:5000/api/search?${params}`)
    if (response.ok) {
      const results = await response.json()
      emit('search', results)
    }
  } catch (error) {
    console.error('搜索失败:', error)
  } finally {
    loading.value = false
  }
}

function clearFilters() {
  searchQuery.value = ''
  cuisineType.value = ''
  difficulty.value = ''
  mealType.value = ''
  performSearch()
}
</script>

<template>
  <div class="search-container card">
    <div class="search-header">
      <div class="header-content">
        <h3 class="search-title">
          <span class="title-icon">🔍</span>
          搜索食谱
        </h3>
        <p class="search-subtitle">发现更多美味食谱</p>
      </div>
      <button @click="clearFilters" class="btn btn-secondary clear-button">
        <span class="btn-icon">🔄</span>
        清除筛选
      </button>
    </div>
    
    <div class="search-form">
      <div class="search-input-group">
        <div class="input-wrapper">
          <span class="input-icon">🔎</span>
          <input 
            type="text" 
            v-model="searchQuery" 
            placeholder="搜索食谱名称或描述..."
            @keyup.enter="performSearch"
            class="search-input input"
          >
        </div>
        <button @click="performSearch" :disabled="loading" class="btn btn-primary search-button">
          <span v-if="loading" class="loading"></span>
          <span v-else class="btn-icon">🚀</span>
          {{ loading ? '搜索中...' : '搜索' }}
        </button>
      </div>
      
      <div class="filters">
        <div class="filter-group">
          <label class="filter-label">
            <span class="label-icon">🍽️</span>
            菜系类型
          </label>
          <select v-model="cuisineType" @change="performSearch" class="filter-select input">
            <option value="">全部菜系</option>
            <option v-for="type in categories.cuisine_types" :key="type" :value="type">
              {{ type }}
            </option>
          </select>
        </div>
        
        <div class="filter-group">
          <label class="filter-label">
            <span class="label-icon">📊</span>
            难度等级
          </label>
          <select v-model="difficulty" @change="performSearch" class="filter-select input">
            <option value="">全部难度</option>
            <option v-for="level in categories.difficulties" :key="level" :value="level">
              {{ level }}
            </option>
          </select>
        </div>
        
        <div class="filter-group">
          <label class="filter-label">
            <span class="label-icon">⏰</span>
            餐食类型
          </label>
          <select v-model="mealType" @change="performSearch" class="filter-select input">
            <option value="">全部类型</option>
            <option v-for="type in categories.meal_types" :key="type" :value="type">
              {{ type }}
            </option>
          </select>
        </div>
      </div>
    </div>
  </div>
</template>

<style scoped>
.search-container {
  margin-bottom: 2rem;
  position: relative;
  overflow: hidden;
}

.search-container::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: linear-gradient(90deg, #667eea, #764ba2, #f093fb, #f5576c);
  border-radius: 2px;
}

.search-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 2rem;
  gap: 1rem;
}

.header-content {
  flex: 1;
}

.search-title {
  font-size: 1.5rem;
  font-weight: 700;
  color: #2c3e50;
  margin: 0 0 0.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.title-icon {
  font-size: 1.8rem;
}

.search-subtitle {
  color: #6c757d;
  font-size: 0.9rem;
  margin: 0;
}

.clear-button {
  white-space: nowrap;
  padding: 0.75rem 1.5rem;
  font-size: 0.9rem;
}

.search-form {
  display: flex;
  flex-direction: column;
  gap: 1.5rem;
}

.search-input-group {
  display: flex;
  gap: 1rem;
  align-items: stretch;
}

.input-wrapper {
  position: relative;
  flex: 1;
}

.input-icon {
  position: absolute;
  left: 1rem;
  top: 50%;
  transform: translateY(-50%);
  font-size: 1.2rem;
  color: #6c757d;
  z-index: 1;
}

.search-input {
  padding-left: 3rem;
  font-size: 1rem;
  height: 100%;
}

.search-button {
  padding: 0 2rem;
  font-weight: 600;
  white-space: nowrap;
  min-width: 120px;
}

.filters {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1.5rem;
}

.filter-group {
  display: flex;
  flex-direction: column;
  gap: 0.5rem;
}

.filter-label {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-weight: 600;
  color: #2c3e50;
  font-size: 0.9rem;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.label-icon {
  font-size: 1rem;
}

.filter-select {
  cursor: pointer;
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%236b7280' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
  background-position: right 0.75rem center;
  background-repeat: no-repeat;
  background-size: 1.5em 1.5em;
  padding-right: 2.5rem;
  appearance: none;
}

.filter-select:focus {
  background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23667eea' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
}

/* 加载动画 */
.loading {
  display: inline-block;
  width: 16px;
  height: 16px;
  border: 2px solid rgba(255, 255, 255, 0.3);
  border-radius: 50%;
  border-top-color: #fff;
  animation: spin 1s ease-in-out infinite;
  margin-right: 0.5rem;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

/* 按钮图标 */
.btn-icon {
  margin-right: 0.5rem;
  font-size: 1rem;
}

/* 响应式设计 */
@media (max-width: 768px) {
  .search-header {
    flex-direction: column;
    align-items: stretch;
    gap: 1rem;
  }
  
  .search-input-group {
    flex-direction: column;
    gap: 1rem;
  }
  
  .search-button {
    min-width: auto;
    width: 100%;
  }
  
  .filters {
    grid-template-columns: 1fr;
    gap: 1rem;
  }
  
  .search-title {
    font-size: 1.3rem;
  }
  
  .title-icon {
    font-size: 1.5rem;
  }
}

/* 深色模式适配 */
@media (prefers-color-scheme: dark) {
  .search-title {
    color: #e1e8ed;
  }
  
  .search-subtitle {
    color: #a0a0a0;
  }
  
  .filter-label {
    color: #e1e8ed;
  }
  
  .input-icon {
    color: #808080;
  }
  
  .filter-select {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23a0a0a0' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
  }
  
  .filter-select:focus {
    background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' fill='none' viewBox='0 0 20 20'%3e%3cpath stroke='%23667eea' stroke-linecap='round' stroke-linejoin='round' stroke-width='1.5' d='m6 8 4 4 4-4'/%3e%3c/svg%3e");
  }
}

/* 悬停效果 */
.search-container:hover {
  transform: translateY(-2px);
  transition: transform 0.3s ease;
}

.filter-select:hover {
  border-color: #667eea;
}

/* 焦点状态增强 */
.search-input:focus,
.filter-select:focus {
  transform: translateY(-1px);
  box-shadow: 0 8px 25px rgba(102, 126, 234, 0.15);
}

/* 动画效果 */
.search-container {
  animation: fadeInUp 0.6s ease-out;
}

.filters {
  animation: slideInUp 0.8s ease-out 0.2s both;
}

@keyframes slideInUp {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}
</style>
